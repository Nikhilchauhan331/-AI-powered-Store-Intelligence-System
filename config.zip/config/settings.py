"""Centralized configuration using Pydantic Settings."""

from pydantic_settings import BaseSettings
from pydantic import Field
from typing import List
import os


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Application
    app_name: str = "store-intelligence-system"
    app_env: str = "development"
    debug: bool = True
    log_level: str = "INFO"

    # Video
    video_source: str = "./data/sample.mp4"
    camera_id: str = "CAM-001"

    # Detection
    yolo_model: str = "yolov8n.pt"
    confidence_threshold: float = 0.5
    iou_threshold: float = 0.45
    target_classes: str = "0"

    # Tracking
    max_age: int = 30
    n_init: int = 3
    max_iou_distance: float = 0.7

    # Kafka
    kafka_bootstrap_servers: str = "localhost:9092"
    kafka_topic_detections: str = "store.detections"
    kafka_topic_analytics: str = "store.analytics"
    kafka_topic_anomalies: str = "store.anomalies"
    kafka_group_id: str = "store-intelligence-consumer"

    # Database
    db_host: str = "localhost"
    db_port: int = 5432
    db_name: str = "store_intelligence"
    db_user: str = "postgres"
    db_password: str = "postgres123"
    database_url: str = "postgresql+asyncpg://postgres:postgres123@localhost:5432/store_intelligence"

    # Redis
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_db: int = 0
    redis_url: str = "redis://localhost:6379/0"

    # API
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    api_workers: int = 4

    # Dashboard
    dashboard_port: int = 8501

    # Anomaly Detection
    loiter_threshold_seconds: int = 60
    overcrowding_threshold: int = 20
    speed_anomaly_threshold: float = 150.0
    zone_dwell_alert_seconds: int = 300

    # Prometheus
    metrics_port: int = 9090

    @property
    def target_class_list(self) -> List[int]:
        return [int(c.strip()) for c in self.target_classes.split(",")]

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()