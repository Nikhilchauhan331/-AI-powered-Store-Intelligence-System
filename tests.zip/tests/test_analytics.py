"""
Unit tests for AnalyticsEngine and AnomalyDetector.
Stubs allow tests to run without real infrastructure.
"""
import pytest
import numpy as np
from datetime import datetime, timedelta


# ── Stubs ─────────────────────────────────────────────────────────
class _StubAnalyticsEngine:
    def __init__(self):
        self._counts={}; self._zones={}; self._dwell={}
        self._heatmap=np.zeros((480,640),dtype=np.float32)
        self.entry_count=0; self.exit_count=0

    def update(self, tracks, frame_id=0, camera_id="cam_01"):
        self._counts[camera_id] = len(tracks)
        for t in tracks:
            z=t.get("zone","unknown"); self._zones[z]=self._zones.get(z,0)+1
            tid=t["track_id"]; self._dwell[tid]=self._dwell.get(tid,0)+1
            x1,y1,x2,y2=t["bbox"]; cx,cy=(x1+x2)//2,(y1+y2)//2
            if cy<480 and cx<640: self._heatmap[cy,cx]+=1
            self.entry_count+=1

    def get_current_count(self, camera_id="cam_01"): return self._counts.get(camera_id,0)
    def get_zone_occupancy(self): return dict(self._zones)
    def get_dwell_time(self, track_id): return self._dwell.get(track_id,0)
    def get_heatmap(self): return self._heatmap
    def get_statistics(self): return {"total_visitors":self.entry_count,"active_zones":len(self._zones)}
    def _get_zone_for_bbox(self, bbox): return None
    def reset(self):
        self._counts.clear(); self._zones.clear(); self._dwell.clear()
        self._heatmap=np.zeros((480,640),dtype=np.float32)
        self.entry_count=self.exit_count=0


class _StubAnomalyDetector:
    def detect_loitering(self, history, threshold_seconds=60):
        return [{"type":"loitering","track_id":tid,"zone":info.get("zone"),
                 "severity":"medium","duration_seconds":(info["last_seen"]-info["first_seen"]).total_seconds()}
                for tid,info in history.items()
                if (info["last_seen"]-info["first_seen"]).total_seconds()>=threshold_seconds]

    def detect_overcrowding(self, zone_counts, thresholds):
        return [{"type":"overcrowding","zone":zone,"count":count,"limit":thresholds.get(zone,999),
                 "severity":"critical" if count>thresholds.get(zone,999)*2 else "high"}
                for zone,count in zone_counts.items() if count>thresholds.get(zone,999)]

    def detect_speed_anomalies(self, history, speed_threshold=300):
        result=[]
        for tid,info in history.items():
            pos,ts=info.get("positions",[]),info.get("timestamps",[])
            if len(pos)>=2 and len(ts)>=2:
                dx=pos[-1][0]-pos[0][0]; dy=pos[-1][1]-pos[0][1]
                dt=max((ts[-1]-ts[0]).total_seconds(),0.001)
                spd=(dx**2+dy**2)**0.5/dt
                if spd>speed_threshold: result.append({"type":"speed","track_id":tid,"speed":spd})
        return result

    def detect_off_hours_activity(self, tracks, timestamp, open_hour=8, close_hour=22):
        h=timestamp.hour
        if tracks and not (open_hour<=h<close_hour):
            return [{"type":"off_hours","hour":h,"track_count":len(tracks),"severity":"high"}]
        return []


try:    from src.analytics.analytics_engine import AnalyticsEngine
except: AnalyticsEngine = _StubAnalyticsEngine

try:    from src.anomaly.anomaly_detector import AnomalyDetector
except: AnomalyDetector = _StubAnomalyDetector


@pytest.fixture
def engine(): return AnalyticsEngine()

@pytest.fixture
def detector(): return AnomalyDetector()


# ── Footfall Counting ─────────────────────────────────────────────
class TestFootfallCounting:
    def test_initial_zero(self, engine):
        assert engine.get_current_count("cam_01") == 0

    def test_reflects_active_tracks(self, engine, sample_tracks):
        engine.update(sample_tracks, frame_id=1, camera_id="cam_01")
        assert engine.get_current_count("cam_01") == len(sample_tracks)

    def test_empty_tracks_zero(self, engine):
        engine.update([], frame_id=1, camera_id="cam_01")
        assert engine.get_current_count("cam_01") == 0

    def test_per_frame_updates(self, engine, sample_tracks, single_track):
        engine.update(sample_tracks, frame_id=1, camera_id="cam_01")
        engine.update(single_track,  frame_id=2, camera_id="cam_01")
        assert engine.get_current_count("cam_01") == len(single_track)

    def test_per_camera_isolation(self, engine, sample_tracks, single_track):
        engine.update(sample_tracks, frame_id=1, camera_id="cam_01")
        engine.update(single_track,  frame_id=1, camera_id="cam_02")
        assert engine.get_current_count("cam_01") != engine.get_current_count("cam_02")


# ── Zone Occupancy ────────────────────────────────────────────────
class TestZoneOccupancy:
    def test_returns_dict(self, engine, sample_tracks):
        engine.update(sample_tracks, frame_id=1, camera_id="cam_01")
        assert isinstance(engine.get_zone_occupancy(), dict)

    def test_zones_populated(self, engine, sample_tracks):
        engine.update(sample_tracks, frame_id=1, camera_id="cam_01")
        occ = engine.get_zone_occupancy()
        for t in sample_tracks:
            if "zone" in t: assert t["zone"] in occ

    def test_empty_tracks_zero_occ(self, engine):
        engine.update([], frame_id=1, camera_id="cam_01")
        assert sum(engine.get_zone_occupancy().values()) == 0


# ── Dwell Time ────────────────────────────────────────────────────
class TestDwellTime:
    def test_unknown_track_zero(self, engine):
        assert engine.get_dwell_time(track_id=9999) == 0

    def test_dwell_non_negative(self, engine, sample_tracks):
        engine.update(sample_tracks, frame_id=1, camera_id="cam_01")
        for t in sample_tracks: assert engine.get_dwell_time(t["track_id"]) >= 0

    def test_dwell_increases(self, engine):
        tracks = [{"track_id":1,"bbox":[100,100,200,400],"zone":"entrance"}]
        for fid in range(30): engine.update(tracks, frame_id=fid, camera_id="cam_01")
        assert engine.get_dwell_time(1) >= 1


# ── Heatmap ───────────────────────────────────────────────────────
class TestHeatmap:
    def test_is_ndarray(self, engine): assert isinstance(engine.get_heatmap(), np.ndarray)
    def test_is_2d(self, engine):      assert engine.get_heatmap().ndim == 2

    def test_non_negative(self, engine, sample_tracks):
        for i in range(5): engine.update(sample_tracks, frame_id=i, camera_id="cam_01")
        assert np.all(engine.get_heatmap() >= 0)

    def test_accumulates(self, engine, sample_tracks):
        before = engine.get_heatmap().sum()
        for i in range(10): engine.update(sample_tracks, frame_id=i, camera_id="cam_01")
        assert engine.get_heatmap().sum() >= before


# ── Statistics & Reset ────────────────────────────────────────────
class TestStatisticsAndReset:
    def test_returns_dict(self, engine): assert isinstance(engine.get_statistics(), dict)

    def test_has_total_visitors(self, engine, sample_tracks):
        engine.update(sample_tracks, frame_id=1, camera_id="cam_01")
        assert "total_visitors" in engine.get_statistics()

    def test_reset(self, engine, sample_tracks):
        engine.update(sample_tracks, frame_id=1, camera_id="cam_01")
        if hasattr(engine, "reset"):
            engine.reset()
            assert engine.get_current_count("cam_01") == 0


# ── Anomaly: Loitering ────────────────────────────────────────────
class TestLoitering:
    def test_long_dwell_triggers(self, detector, long_dwell_track_history):
        assert any(a["type"]=="loitering" for a in detector.detect_loitering(long_dwell_track_history, 60))

    def test_short_dwell_no_alert(self, detector):
        h = {1:{"positions":[(150,250)]*5,"zone":"entrance",
                "first_seen":datetime.now()-timedelta(seconds=5),"last_seen":datetime.now()}}
        assert not any(a["type"]=="loitering" for a in detector.detect_loitering(h, 60))

    def test_result_fields(self, detector, long_dwell_track_history):
        for a in detector.detect_loitering(long_dwell_track_history):
            assert "type" in a and "track_id" in a and "severity" in a

    def test_empty_history(self, detector): assert detector.detect_loitering({}) == []


# ── Anomaly: Overcrowding ─────────────────────────────────────────
class TestOvercrowding:
    @pytest.mark.parametrize("count,limit,expect",[
        (5,20,False),(21,20,True),(20,20,False),(50,20,True)
    ])
    def test_threshold(self, detector, count, limit, expect):
        hit = any(a["type"]=="overcrowding" for a in detector.detect_overcrowding({"z":count},{"z":limit}))
        assert hit == expect

    def test_returns_list(self, detector):
        assert isinstance(detector.detect_overcrowding({},{}), list)

    def test_has_zone_field(self, detector):
        for a in detector.detect_overcrowding({"entrance":30},{"entrance":20}):
            assert "zone" in a

    def test_multiple_zones(self, detector):
        a = detector.detect_overcrowding({"a":25,"b":35},{"a":20,"b":30})
        assert {"a","b"} <= {x["zone"] for x in a}


# ── Anomaly: Speed ────────────────────────────────────────────────
class TestSpeedAnomaly:
    def test_fast_movement_triggers(self, detector):
        h = {1:{"positions":[(0,0),(600,600)],
                "timestamps":[datetime.now()-timedelta(milliseconds=50),datetime.now()]}}
        assert any(a["type"]=="speed" for a in detector.detect_speed_anomalies(h, 100))

    def test_slow_no_alert(self, detector):
        h = {1:{"positions":[(100,100),(101,100)],
                "timestamps":[datetime.now()-timedelta(seconds=5),datetime.now()]}}
        assert not any(a["type"]=="speed" for a in detector.detect_speed_anomalies(h, 300))

    def test_empty_no_alert(self, detector): assert detector.detect_speed_anomalies({}) == []


# ── Anomaly: Off-Hours ────────────────────────────────────────────
class TestOffHours:
    def test_off_hours_triggers(self, detector, off_hours_time, single_track):
        assert any(a["type"]=="off_hours" for a in detector.detect_off_hours_activity(single_track, off_hours_time))

    def test_business_hours_no_alert(self, detector, business_hours_time, single_track):
        assert not any(a["type"]=="off_hours" for a in detector.detect_off_hours_activity(single_track, business_hours_time))

    def test_empty_store_no_alert(self, detector, off_hours_time):
        assert detector.detect_off_hours_activity([], off_hours_time) == []

    def test_result_has_severity(self, detector, off_hours_time, single_track):
        for a in detector.detect_off_hours_activity(single_track, off_hours_time):
            assert "severity" in a