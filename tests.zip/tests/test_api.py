"""Integration tests for FastAPI REST + WebSocket endpoints."""
import pytest
from unittest.mock import MagicMock, patch


def _make_client():
    with patch("src.storage.database.DatabaseManager",   MagicMock()), \
         patch("src.storage.redis_client.CacheManager", MagicMock()), \
         patch("src.analytics.analytics_engine.AnalyticsEngine", MagicMock()):
        from src.api.main import app
        from fastapi.testclient import TestClient
        return TestClient(app)

@pytest.fixture(scope="module")
def client(): return _make_client()


class TestHealthEndpoints:
    def test_health_200(self, client):     assert client.get("/health").status_code == 200
    def test_health_status_key(self, client): assert "status" in client.get("/health").json()
    def test_root_200(self, client):       assert client.get("/").status_code == 200
    def test_docs_200(self, client):       assert client.get("/docs").status_code == 200


class TestPeopleCountEndpoints:
    def test_current_count_200(self, client):
        assert client.get("/api/v1/analytics/count/current").status_code == 200

    def test_current_count_is_int(self, client):
        data = client.get("/api/v1/analytics/count/current").json()
        assert "count" in data and isinstance(data["count"], int)

    def test_count_non_negative(self, client):
        assert client.get("/api/v1/analytics/count/current").json()["count"] >= 0

    def test_history_valid_window(self, client):
        assert client.get("/api/v1/analytics/count/history?minutes=30").status_code in (200, 422)

    def test_history_returns_list(self, client):
        r = client.get("/api/v1/analytics/count/history?minutes=30")
        if r.status_code == 200: assert isinstance(r.json(), list)

    def test_history_negative_minutes(self, client):
        assert client.get("/api/v1/analytics/count/history?minutes=-5").status_code in (200, 422)


class TestZoneEndpoints:
    def test_occupancy_200(self, client):
        assert client.get("/api/v1/analytics/zones/occupancy").status_code == 200

    def test_occupancy_is_dict(self, client):
        assert isinstance(client.get("/api/v1/analytics/zones/occupancy").json(), dict)

    def test_heatmap_accessible(self, client):
        assert client.get("/api/v1/analytics/zones/heatmap").status_code in (200, 404, 500)

    def test_specific_zone(self, client):
        assert client.get("/api/v1/analytics/zones/entrance").status_code in (200, 404)

    def test_unknown_zone(self, client):
        assert client.get("/api/v1/analytics/zones/zone_xyz_unknown").status_code in (200, 404)


class TestTrackEndpoints:
    def test_active_tracks_200(self, client):
        assert client.get("/api/v1/tracks/active").status_code == 200

    def test_active_tracks_list(self, client):
        assert isinstance(client.get("/api/v1/tracks/active").json(), list)

    def test_track_by_int_id(self, client):
        assert client.get("/api/v1/tracks/1").status_code in (200, 404)

    def test_track_string_rejected(self, client):
        assert client.get("/api/v1/tracks/not_a_number").status_code in (404, 422)


class TestAnomalyEndpoints:
    def test_active_200(self, client):
        assert client.get("/api/v1/anomalies/active").status_code == 200

    def test_active_is_list(self, client):
        assert isinstance(client.get("/api/v1/anomalies/active").json(), list)

    def test_history_accessible(self, client):
        assert client.get("/api/v1/anomalies/history").status_code in (200, 422)

    def test_filter_by_type(self, client):
        assert client.get("/api/v1/anomalies/active?type=loitering").status_code in (200, 422)


class TestEventEndpoints:
    def test_recent_200(self, client):
        assert client.get("/api/v1/events/recent").status_code == 200

    def test_recent_is_list(self, client):
        assert isinstance(client.get("/api/v1/events/recent").json(), list)

    def test_filter_by_camera(self, client):
        assert client.get("/api/v1/events/recent?camera_id=cam_01").status_code in (200, 422)


class TestWebSocket:
    def test_ws_connection(self, client):
        with client.websocket_connect("/api/v1/ws/events") as ws:
            assert ws is not None

    def test_ws_sends_json(self, client):
        with client.websocket_connect("/api/v1/ws/events") as ws:
            try:
                assert isinstance(ws.receive_json(timeout=1), dict)
            except Exception:
                pass  # timeout is OK — connection itself passed


class TestInputValidation:
    def test_nonexistent_404(self, client):
        assert client.get("/api/v1/this_does_not_exist").status_code == 404

    def test_wrong_method(self, client):
        assert client.delete("/api/v1/analytics/count/current").status_code in (405, 404)

    def test_response_is_json(self, client):
        r = client.get("/api/v1/analytics/count/current")
        assert "application/json" in r.headers.get("content-type", "")