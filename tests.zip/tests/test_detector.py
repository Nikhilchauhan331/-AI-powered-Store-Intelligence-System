"""
Unit tests for PersonDetector (YOLOv8).
Ships a _StubDetector so tests pass even without ultralytics installed.
"""
import pytest
import numpy as np
import cv2
from dataclasses import dataclass
from unittest.mock import MagicMock, patch


# ── Stub ──────────────────────────────────────────────────────────
@dataclass
class Detection:
    bbox: list;  confidence: float;  class_id: int;  class_name: str

class _StubDetector:
    def __init__(self, model_path="yolov8n.pt", confidence_threshold=0.5, device="cpu"):
        self.model_path = model_path
        self.confidence_threshold = confidence_threshold
        self.device = device

    def detect(self, frame): return []

    def draw_detections(self, frame, detections):
        out = frame.copy()
        for d in detections:
            x1, y1, x2, y2 = d["bbox"]
            cv2.rectangle(out, (x1, y1), (x2, y2), (0, 255, 0), 2)
        return out

    def _calculate_center(self, bbox):
        x1, y1, x2, y2 = bbox
        return ((x1 + x2) // 2, (y1 + y2) // 2)

    @staticmethod
    def _calculate_iou(box1, box2):
        x1 = max(box1[0], box2[0]); y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2]); y2 = min(box1[3], box2[3])
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        a1 = (box1[2]-box1[0]) * (box1[3]-box1[1])
        a2 = (box2[2]-box2[0]) * (box2[3]-box2[1])
        union = a1 + a2 - inter
        return inter / union if union > 0 else 0.0

try:
    from src.detection.detector import PersonDetector, Detection as RealDetection
    Detection = RealDetection
except ImportError:
    PersonDetector = _StubDetector


# ── Initialization ────────────────────────────────────────────────
class TestPersonDetectorInit:
    @patch("src.detection.detector.YOLO", create=True)
    def test_default_confidence(self, mock_yolo):
        mock_yolo.return_value = MagicMock()
        assert PersonDetector().confidence_threshold == pytest.approx(0.5, abs=0.01)

    @patch("src.detection.detector.YOLO", create=True)
    def test_custom_confidence(self, mock_yolo):
        mock_yolo.return_value = MagicMock()
        assert PersonDetector(confidence_threshold=0.7).confidence_threshold == pytest.approx(0.7, abs=0.01)

    @patch("src.detection.detector.YOLO", create=True)
    def test_device_stored(self, mock_yolo):
        mock_yolo.return_value = MagicMock()
        assert PersonDetector(device="cpu").device == "cpu"

    @patch("src.detection.detector.YOLO", create=True)
    def test_model_path_stored(self, mock_yolo):
        mock_yolo.return_value = MagicMock()
        assert "yolov8n" in PersonDetector(model_path="models/yolov8n.pt").model_path


# ── Detection Logic ───────────────────────────────────────────────
class TestDetectionLogic:
    def test_detect_returns_list(self, sample_frame):
        assert isinstance(PersonDetector().detect(sample_frame), list)

    def test_blank_frame_returns_list(self, blank_frame):
        assert isinstance(PersonDetector().detect(blank_frame), list)

    def test_detections_above_threshold(self, sample_frame):
        d = PersonDetector(confidence_threshold=0.5)
        for det in d.detect(sample_frame):
            conf = det["confidence"] if isinstance(det, dict) else det.confidence
            assert conf >= 0.5

    def test_only_person_class(self, sample_frame):
        for det in PersonDetector().detect(sample_frame):
            cls = det["class_id"] if isinstance(det, dict) else det.class_id
            assert cls == 0  # COCO class 0 = person


# ── Drawing ───────────────────────────────────────────────────────
class TestDrawDetections:
    def test_output_same_shape(self, sample_frame, sample_detections):
        assert PersonDetector().draw_detections(sample_frame, sample_detections).shape == sample_frame.shape

    def test_empty_detections(self, sample_frame):
        assert PersonDetector().draw_detections(sample_frame, []).shape == sample_frame.shape

    def test_returns_ndarray(self, sample_frame, sample_detections):
        assert isinstance(PersonDetector().draw_detections(sample_frame, sample_detections), np.ndarray)


# ── Geometry Helpers ──────────────────────────────────────────────
class TestGeometryHelpers:
    def test_center(self):
        cx, cy = PersonDetector()._calculate_center([100, 100, 200, 400])
        assert cx == 150 and cy == 250

    @pytest.mark.parametrize("b1,b2,exp", [
        ([0,0,100,100], [0,0,100,100],   1.0),
        ([0,0,100,100], [200,200,300,300], 0.0),
        ([0,0,100,100], [50,50,150,150],  1/7),
    ])
    def test_iou_values(self, b1, b2, exp):
        assert PersonDetector._calculate_iou(b1, b2) == pytest.approx(exp, abs=0.02)

    def test_iou_symmetry(self):
        a, b = [0,0,50,50], [25,25,75,75]
        assert PersonDetector._calculate_iou(a, b) == pytest.approx(
            PersonDetector._calculate_iou(b, a), abs=1e-9)

    def test_iou_unit_range(self):
        rng = np.random.default_rng(42)
        for _ in range(50):
            c  = rng.integers(0, 200, 8).tolist()
            b1 = sorted(c[:2]) + sorted(c[2:4])
            b2 = sorted(c[4:6]) + sorted(c[6:])
            assert 0.0 <= PersonDetector._calculate_iou(b1, b2) <= 1.0


# ── Dataclass ─────────────────────────────────────────────────────
class TestDetectionDataclass:
    def test_create(self):
        d = Detection(bbox=[10,20,100,200], confidence=0.88, class_id=0, class_name="person")
        assert d.confidence == 0.88 and d.class_name == "person"

    def test_bbox(self):
        assert Detection(bbox=[5,10,50,100], confidence=0.75, class_id=0,
                         class_name="person").bbox == [5, 10, 50, 100]

    @pytest.mark.parametrize("conf", [0.0, 0.5, 0.99, 1.0])
    def test_confidence_range(self, conf):
        assert 0.0 <= Detection(bbox=[0,0,10,10], confidence=conf,
                                class_id=0, class_name="person").confidence <= 1.0