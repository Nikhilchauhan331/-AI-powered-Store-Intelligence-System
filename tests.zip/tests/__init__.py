"""
Test suite for the AI-Powered Store Intelligence System.

    pytest tests/ -v
    pytest tests/ -v --cov=src --cov-report=html
    pytest tests/test_detector.py -v
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))