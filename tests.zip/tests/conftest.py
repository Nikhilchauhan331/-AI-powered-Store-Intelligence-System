"""
Shared pytest fixtures — auto-available in every test file, no imports needed.
"""
import pytest
import asyncio
import numpy as np
import cv2
import json
from unittest.mock import MagicMock
from datetime import datetime, timedelta


# ─── Frames ───────────────────────────────────────────────────────
@pytest.fixture
def sample_frame():
    """640×480 BGR frame with two white rectangles (person silhouettes)."""
    frame = np.zeros((480, 640, 3), dtype=np.uint8)
    cv2.rectangle(frame, (100, 100), (200, 400), (255, 255, 255), -1)
    cv2.rectangle(frame, (300, 150), (400, 450), (200, 200, 200), -1)
    return frame

@pytest.fixture
def blank_frame():
    """Completely black frame — no people."""
    return np.zeros((480, 640, 3), dtype=np.uint8)

@pytest.fixture
def sample_frames(sample_frame):
    return [sample_frame.copy() for _ in range(10)]


# ─── Detections ───────────────────────────────────────────────────
@pytest.fixture
def sample_detections():
    return [
        {"bbox": [100, 100, 200, 400], "confidence": 0.92, "class_id": 0, "class_name": "person"},
        {"bbox": [300, 150, 400, 450], "confidence": 0.87, "class_id": 0, "class_name": "person"},
    ]

@pytest.fixture
def single_detection():
    return [{"bbox": [150, 100, 250, 400], "confidence": 0.95, "class_id": 0, "class_name": "person"}]

@pytest.fixture
def low_confidence_detections():
    return [{"bbox": [100, 100, 200, 400], "confidence": 0.30, "class_id": 0, "class_name": "person"}]


# ─── Tracks ───────────────────────────────────────────────────────
@pytest.fixture
def sample_tracks():
    return [
        {"track_id": 1, "bbox": [100, 100, 200, 400], "confidence": 0.92,
         "age": 5, "hits": 5, "zone": "entrance"},
        {"track_id": 2, "bbox": [300, 150, 400, 450], "confidence": 0.87,
         "age": 3, "hits": 3, "zone": "aisle_1"},
    ]

@pytest.fixture
def single_track():
    return [{"track_id": 10, "bbox": [200, 100, 300, 400], "confidence": 0.90,
             "age": 8, "hits": 8, "zone": "checkout"}]


# ─── Events ───────────────────────────────────────────────────────
@pytest.fixture
def sample_event():
    return {
        "event_id": "test-event-001", "event_type": "person_detected",
        "timestamp": datetime.now().isoformat(), "camera_id": "cam_01",
        "zone_id": "entrance", "track_id": 1,
        "bbox": [100, 100, 200, 400], "confidence": 0.92, "metadata": {},
    }

@pytest.fixture
def anomaly_event():
    return {
        "event_id": "anom-001", "event_type": "anomaly_detected",
        "anomaly_type": "loitering", "timestamp": datetime.now().isoformat(),
        "camera_id": "cam_01", "zone_id": "entrance", "track_id": 5,
        "severity": "medium", "duration_seconds": 120, "metadata": {},
    }


# ─── Infrastructure Mocks ─────────────────────────────────────────
@pytest.fixture
def mock_redis():
    m = MagicMock()
    m.get.return_value     = None;  m.set.return_value    = True
    m.setex.return_value   = True;  m.incr.return_value   = 1
    m.expire.return_value  = True;  m.hget.return_value   = None
    m.hset.return_value    = True;  m.hgetall.return_value = {}
    m.lpush.return_value   = 1;     m.lrange.return_value  = []
    m.delete.return_value  = 1;     m.ping.return_value    = True
    return m

@pytest.fixture
def mock_db():
    m      = MagicMock()
    cursor = MagicMock()
    cursor.execute.return_value  = None
    cursor.fetchall.return_value = []
    cursor.fetchone.return_value = None
    cursor.rowcount              = 0
    m.cursor.return_value.__enter__ = MagicMock(return_value=cursor)
    m.cursor.return_value.__exit__  = MagicMock(return_value=False)
    m.commit.return_value = None
    return m

@pytest.fixture
def mock_kafka_producer():
    m = MagicMock()
    m.send.return_value = MagicMock(); m.flush.return_value = None
    m.close.return_value = None
    return m

@pytest.fixture
def mock_kafka_consumer():
    m   = MagicMock()
    msg = MagicMock()
    msg.value = json.dumps(
        {"event_type": "person_detected", "track_id": 1, "camera_id": "cam_01"}
    ).encode()
    m.__iter__ = MagicMock(return_value=iter([msg]))
    return m


# ─── FastAPI Client ───────────────────────────────────────────────
@pytest.fixture
def app_client():
    from unittest.mock import patch
    with patch("src.storage.database.DatabaseManager",   MagicMock()), \
         patch("src.storage.redis_client.CacheManager", MagicMock()), \
         patch("src.analytics.analytics_engine.AnalyticsEngine", MagicMock()):
        from src.api.main import app
        from fastapi.testclient import TestClient
        yield TestClient(app)


# ─── Async + Temporal ─────────────────────────────────────────────
@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()

@pytest.fixture
def business_hours_time():
    return datetime.now().replace(hour=14, minute=0, second=0, microsecond=0)

@pytest.fixture
def off_hours_time():
    return datetime.now().replace(hour=3, minute=0, second=0, microsecond=0)

@pytest.fixture
def long_dwell_track_history():
    start = datetime.now() - timedelta(seconds=180)
    return {1: {"positions": [(150, 250 + i) for i in range(180)],
                "zone": "entrance", "first_seen": start, "last_seen": datetime.now()}}