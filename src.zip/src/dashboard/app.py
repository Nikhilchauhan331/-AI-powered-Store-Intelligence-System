"""Streamlit real-time dashboard for Store Intelligence System."""

import streamlit as st
import requests
import plotly.express as px
import pandas as pd
import time
import os
import yaml
from datetime import datetime
from pathlib import Path

st.set_page_config(
    page_title="Store Intelligence Dashboard",
    page_icon="🏪",
    layout="wide",
    initial_sidebar_state="expanded",
)

API_HOST = os.getenv("API_HOST", "http://localhost:8000")
API_BASE = f"{API_HOST}/api/v1"
ROOT_DIR = Path(__file__).resolve().parents[2]
CONFIG_PATH = ROOT_DIR / "config" / "config.yaml"


@st.cache_data(show_spinner=False)
def load_dashboard_config():
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as handle:
            return yaml.safe_load(handle) or {}
    except Exception:
        return {}


def build_demo_snapshot():
    config = load_dashboard_config()
    zone_defs = config.get("zones", [])
    zone_ids = [zone.get("id", f"zone_{index + 1}") for index, zone in enumerate(zone_defs)]
    zone_names = {
        zone.get("id", f"zone_{index + 1}"): zone.get("name", f"Zone {index + 1}")
        for index, zone in enumerate(zone_defs)
    }
    demo_zone_counts = {}

    for index, zone_id in enumerate(zone_ids):
        demo_zone_counts[zone_id] = [3, 2, 4, 1][index % 4]

    demo_tracks = []
    for index, zone_id in enumerate(zone_ids[:4]):
        demo_tracks.append({
            "track_id": 200 + index,
            "confidence": 0.92 - index * 0.03,
            "zone_id": zone_id,
            "dwell_time": 18.5 + index * 6.0,
            "speed": 0.014 + index * 0.006,
        })

    demo_anomalies = [
        {
            "severity": "high",
            "anomaly_type": "overcrowding",
            "description": "Checkout zone exceeded its comfort limit for several frames.",
            "zone_id": zone_ids[1] if len(zone_ids) > 1 else None,
        },
        {
            "severity": "medium",
            "anomaly_type": "loitering",
            "description": "A visitor stayed near the entrance longer than the configured threshold.",
            "zone_id": zone_ids[0] if zone_ids else None,
        },
        {
            "severity": "high",
            "anomaly_type": "off_hours_activity",
            "description": "Movement was detected outside the configured store hours.",
            "zone_id": None,
        },
    ]

    demo_events = [
        {
            "timestamp": "2026-06-03T10:15:02Z",
            "event_type": "detection",
            "camera_id": "cam_01",
            "zone_id": zone_ids[0] if zone_ids else "zone_entrance",
        },
        {
            "timestamp": "2026-06-03T10:15:07Z",
            "event_type": "zone_update",
            "camera_id": "cam_01",
            "zone_id": zone_ids[1] if len(zone_ids) > 1 else "zone_checkout",
        },
        {
            "timestamp": "2026-06-03T10:15:12Z",
            "event_type": "anomaly",
            "camera_id": "cam_01",
            "zone_id": None,
        },
    ]

    heatmap = [[0.0 for _ in range(8)] for _ in range(8)]
    for row, col, value in [(1, 1, 0.3), (1, 2, 0.5), (2, 2, 0.85), (4, 4, 0.7), (5, 5, 0.55), (6, 2, 0.4)]:
        heatmap[row][col] = value

    anomaly_cfg = config.get("anomaly", {})

    return {
        "mode": "demo",
        "health": {
            "status": "demo",
            "services": {
                "api": "ready",
                "detection": "waiting for video",
                "tracking": "waiting for live stream",
                "analytics": "using sample snapshot",
            },
        },
        "count": {"count": 4},
        "stats": {
            "total_visitors": 128,
            "current_occupancy": 4,
            "active_zones": len([count for count in demo_zone_counts.values() if count > 0]),
            "active_anomalies": len(demo_anomalies),
            "avg_dwell_time": 42.7,
            "peak_occupancy": 9,
            "fps": 18.6,
            "uptime_seconds": 5432.0,
        },
        "zone_data": {
            "zones": demo_zone_counts,
            "total_people": sum(demo_zone_counts.values()),
            "timestamp": "2026-06-03T10:15:12Z",
        },
        "tracks": demo_tracks,
        "anomalies": demo_anomalies,
        "events": demo_events,
        "heatmap": {
            "data": heatmap,
            "width": 8,
            "height": 8,
        },
        "zones": zone_defs,
        "zone_names": zone_names,
        "anomaly_rules": [
            {
                "name": "Loitering",
                "detail": f"Visible when a track stays still for more than {anomaly_cfg.get('loitering_threshold_seconds', 30)} seconds.",
            },
            {
                "name": "Overcrowding",
                "detail": "Triggers when a zone exceeds its configured alert capacity.",
            },
            {
                "name": "Speed anomaly",
                "detail": f"Flags movement faster than {anomaly_cfg.get('speed_multiplier_threshold', 3.0)}x the rolling baseline.",
            },
            {
                "name": "Off-hours activity",
                "detail": f"Detects detections before {anomaly_cfg.get('off_hours_end', 6)}:00 or after {anomaly_cfg.get('off_hours_start', 22)}:00.",
            },
            {
                "name": "Zone dwell",
                "detail": f"Warns when a person remains in a zone beyond {anomaly_cfg.get('dwell_time_threshold_seconds', 120)} seconds.",
            },
        ],
    }


def as_dataframe_rows(items, fields):
    return pd.DataFrame([{field: item.get(field, "") for field in fields} for item in items])


def fetch_api(path, params=None):
    """GET from API; returns parsed JSON or {"error": ...}."""
    # health endpoint lives at root, not under /api/v1
    url = f"{API_HOST}/{path}" if path == "health" else f"{API_BASE}/{path}"
    try:
        resp = requests.get(url, params=params, timeout=5)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        return {"error": str(e)}


def has_live_signal(*payloads):
    for payload in payloads:
        if isinstance(payload, list) and payload:
            return True
        if isinstance(payload, dict):
            if payload.get("error"):
                continue
            if payload.get("count", 0) or payload.get("total_people", 0):
                return True
            if payload.get("zones"):
                return True
            if payload.get("data"):
                return True
            if payload.get("total_visitors", 0) or payload.get("current_occupancy", 0):
                return True
    return False


# ── Sidebar ───────────────────────────────────────────────────────
st.sidebar.title("🏪 Store Intelligence")
refresh_rate  = st.sidebar.slider("Refresh Rate (seconds)", 1, 30, 5)
show_heatmap  = st.sidebar.checkbox("Show Heatmap", True)
show_anomalies = st.sidebar.checkbox("Show Anomalies", True)
st.sidebar.markdown("---")
st.sidebar.caption("Live mode depends on the API plus an active video pipeline. If nothing is streaming yet, the dashboard shows a guided demo snapshot.")
if st.sidebar.button("🔄 Refresh Now"):
    st.rerun()

# ── Header ────────────────────────────────────────────────────────
st.markdown(
    "<div style='padding:1.2rem 1.4rem;border-radius:1.2rem;background:linear-gradient(135deg, #0f172a 0%, #1f2937 100%);color:white;border:1px solid rgba(255,255,255,0.08);'>"
    "<div style='font-size:2rem;font-weight:800;line-height:1.1;'>Store Intelligence Dashboard</div>"
    "<div style='opacity:0.85;margin-top:0.35rem;'>Track people flow, zone occupancy, anomalies, and recent activity from a live CCTV pipeline.</div>"
    f"<div style='margin-top:0.65rem;font-size:0.9rem;opacity:0.75;'>Last updated: {datetime.now().strftime('%H:%M:%S')}</div>"
    "</div>",
    unsafe_allow_html=True,
)

health     = fetch_api("health")
count_data = fetch_api("analytics/count/current")
stats_data = fetch_api("analytics/statistics")
anom_data  = fetch_api("anomalies/active")
tracks_data = fetch_api("tracks/active")
zone_data = fetch_api("analytics/zones/occupancy")
heatmap = fetch_api("analytics/zones/heatmap")
events = fetch_api("events/recent", {"limit": 10})

demo = build_demo_snapshot()
use_demo = not has_live_signal(health, count_data, stats_data, anom_data, tracks_data, zone_data, heatmap, events)
if use_demo:
    health = demo["health"]
    count_data = demo["count"]
    stats_data = demo["stats"]
    anom_data = demo["anomalies"]
    tracks_data = demo["tracks"]
    zone_data = demo["zone_data"]
    heatmap = demo["heatmap"]
    events = demo["events"]

mode_label = "Demo snapshot" if use_demo else "Live data"
mode_color = "#f59e0b" if use_demo else "#22c55e"
st.markdown(
    f"<div style='margin:0.8rem 0 0.35rem 0;padding:0.75rem 1rem;border-radius:0.9rem;background:rgba(15,23,42,0.04);border:1px solid rgba(15,23,42,0.08);display:flex;justify-content:space-between;align-items:center;'>"
    f"<div><strong>Status:</strong> <span style='color:{mode_color};font-weight:700;'>{mode_label}</span>"
    f"<span style='margin-left:0.8rem;color:#6b7280;'>Zones, events, tracks, and anomalies refresh automatically.</span></div>"
    f"<div style='color:#6b7280;'>API: {API_HOST}</div>"
    "</div>",
    unsafe_allow_html=True,
)
if use_demo:
    st.info("No live stream data is available yet, so this page is showing a guided snapshot built from your configured zones and anomaly thresholds.")

# ── Top metrics ───────────────────────────────────────────────────
col1, col2, col3, col4 = st.columns(4)

with col1:
    people = count_data.get("count", 0) if "error" not in count_data else 0
    st.metric("👥 Current People", people)
with col2:
    visitors = stats_data.get("total_visitors", 0) if "error" not in stats_data else 0
    st.metric("🚶 Total Footfall", visitors)
with col3:
    status = health.get("status", "unknown").upper() if "error" not in health else "ERROR"
    st.metric("💚 System Status", status)
with col4:
    anom_count = len(anom_data) if isinstance(anom_data, list) else 0
    st.metric("⚠️ Active Anomalies", anom_count)

st.markdown("---")

# ── How it works ─────────────────────────────────────────────────
st.subheader("How the system works")
workflow_cols = st.columns(4)
workflow_steps = [
    ("1. Detect", "YOLOv8 finds people in the video frame."),
    ("2. Track", "Tracks keep the same person identity over time."),
    ("3. Map zones", "Each track is assigned to an entrance, checkout, or product zone."),
    ("4. Flag anomalies", "Rules detect loitering, overcrowding, off-hours activity, speed spikes, and long dwell times."),
]
for col, (title, text) in zip(workflow_cols, workflow_steps):
    with col:
        st.markdown(
            f"<div style='height:100%;padding:1rem;border-radius:0.9rem;background:white;border:1px solid rgba(15,23,42,0.08);box-shadow:0 8px 24px rgba(15,23,42,0.04);'>"
            f"<div style='font-weight:700;margin-bottom:0.35rem;'>{title}</div>"
            f"<div style='color:#4b5563;font-size:0.95rem;'>{text}</div>"
            "</div>",
            unsafe_allow_html=True,
        )

st.markdown("---")

# ── Tracks + Zone occupancy ───────────────────────────────────────
col_left, col_right = st.columns([3, 2])

with col_left:
    st.subheader("📍 Active Tracks")
    if isinstance(tracks_data, list) and tracks_data:
        df = pd.DataFrame([{
            "Track ID":   t.get("track_id", "?"),
            "Confidence": f"{t.get('confidence', 0):.2f}",
            "Zone":       t.get("zone_id", "—"),
            "Dwell (s)":  f"{t.get('dwell_time', 0):.1f}",
            "Speed":      f"{t.get('speed', 0):.3f}",
        } for t in tracks_data])
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("No active tracks are currently available from the pipeline.")
        if use_demo:
            st.caption("The demo snapshot shows how tracks will appear once detections start flowing.")

with col_right:
    st.subheader("🗺️ Zone Occupancy")
    if "error" not in zone_data and zone_data.get("zones"):
        zones = zone_data["zones"]
        fig = px.bar(
            x=list(zones.keys()),
            y=list(zones.values()),
            labels={"x": "Zone", "y": "People"},
            color=list(zones.values()),
            color_continuous_scale="RdYlGn_r",
        )
        fig.update_layout(height=300, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No zone data is available yet.")
        if use_demo and demo["zones"]:
            zone_table = pd.DataFrame([
                {
                    "Zone ID": zone.get("id", ""),
                    "Name": zone.get("name", ""),
                    "Alert capacity": zone.get("alert_capacity", ""),
                    "Points": len(zone.get("coordinates", [])),
                }
                for zone in demo["zones"]
            ])
            st.dataframe(zone_table, use_container_width=True, hide_index=True)

st.markdown("---")

# ── Statistics + Heatmap ──────────────────────────────────────────
col_a, col_b = st.columns(2)

with col_a:
    st.subheader("📊 Statistics")
    if "error" not in stats_data:
        s = stats_data
        st.write(f"**Avg dwell time:** {s.get('avg_dwell_time', 0):.1f}s")
        st.write(f"**Peak occupancy:** {s.get('peak_occupancy', 0)}")
        st.write(f"**Active zones:**   {s.get('active_zones', 0)}")
        st.write(f"**FPS:**            {s.get('fps', 0):.1f}")
    else:
        st.info("Collecting data…")

    if use_demo:
        st.caption("Demo stats mirror the dashboard behavior you should expect once the pipeline is running.")

with col_b:
    if show_heatmap:
        st.subheader("🔥 Activity Heatmap")
        if "error" not in heatmap and heatmap.get("data"):
            grid = pd.DataFrame(heatmap["data"]).to_numpy(dtype=float)
            fig = px.imshow(
                grid,
                color_continuous_scale="hot",
                labels={"color": "Activity"},
                aspect="equal",
            )
            fig.update_layout(height=300)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Heatmap data not available.")
            if use_demo:
                demo_heat = pd.DataFrame(demo["heatmap"]["data"])
                fig = px.imshow(demo_heat, color_continuous_scale="hot", aspect="equal")
                fig.update_layout(height=300, showlegend=False)
                st.plotly_chart(fig, use_container_width=True)

st.markdown("---")

# ── Zones + anomaly catalog ───────────────────────────────────────
col_catalog, col_zones = st.columns([2, 3])

with col_catalog:
    st.subheader("What anomalies it shows")
    rules = demo["anomaly_rules"] if use_demo else [
        {"name": "Loitering", "detail": "Triggered when a person remains still beyond the configured threshold."},
        {"name": "Overcrowding", "detail": "Triggered when a zone crosses its allowed capacity."},
        {"name": "Speed anomaly", "detail": "Triggered when movement is much faster than the rolling baseline."},
        {"name": "Off-hours activity", "detail": "Triggered when detections appear outside store hours."},
        {"name": "Zone dwell", "detail": "Triggered when a person stays in one zone for too long."},
    ]
    for rule in rules:
        st.markdown(
            f"<div style='margin-bottom:0.7rem;padding:0.85rem 0.95rem;border-radius:0.9rem;background:#fff;border:1px solid rgba(15,23,42,0.08);'>"
            f"<div style='font-weight:700;'>{rule['name']}</div>"
            f"<div style='color:#4b5563;font-size:0.94rem;margin-top:0.2rem;'>{rule['detail']}</div>"
            "</div>",
            unsafe_allow_html=True,
        )

with col_zones:
    st.subheader("Zone catalog")
    zones = demo["zones"] if use_demo else []
    if zones:
        zone_table = pd.DataFrame([
            {
                "Zone ID": zone.get("id", ""),
                "Name": zone.get("name", ""),
                "Alert capacity": zone.get("alert_capacity", ""),
                "Polygon points": len(zone.get("coordinates", [])),
            }
            for zone in zones
        ])
        st.dataframe(zone_table, use_container_width=True, hide_index=True)
    else:
        st.info("No zone definitions were loaded from the backend yet.")

# ── Recent Anomalies ──────────────────────────────────────────────
if show_anomalies:
    st.markdown("---")
    st.subheader("🚨 Recent Anomalies")
    if isinstance(anom_data, list) and anom_data:
        icons = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🟢"}
        for a in anom_data[:10]:
            sev = a.get("severity", "low")
            with st.expander(
                f"{icons.get(sev, '⚪')} [{sev.upper()}] {a.get('anomaly_type', '?')}"
            ):
                st.write(f"**{a.get('description', '')}**")
                if a.get("zone_id"):
                    st.write(f"Zone: {a['zone_id']}")
    else:
        st.success("✅ No active anomalies — all clear right now.")

# ── Recent Events ─────────────────────────────────────────────────
st.markdown("---")
st.subheader("📋 Recent Events")
if isinstance(events, list) and events:
    df_ev = as_dataframe_rows(events, ["timestamp", "event_type", "camera_id", "zone_id"])
    df_ev = df_ev.rename(columns={"timestamp": "Time", "event_type": "Type", "camera_id": "Camera", "zone_id": "Zone"})
    st.dataframe(df_ev, use_container_width=True, hide_index=True)
else:
    st.info("No recent events are available yet.")
    if use_demo:
        demo_events = as_dataframe_rows(demo["events"], ["timestamp", "event_type", "camera_id", "zone_id"])
        demo_events = demo_events.rename(columns={"timestamp": "Time", "event_type": "Type", "camera_id": "Camera", "zone_id": "Zone"})
        st.dataframe(demo_events, use_container_width=True, hide_index=True)

# ── Auto-refresh ──────────────────────────────────────────────────
time.sleep(refresh_rate)
st.rerun()
