"""
Store Intelligence System — AI-powered CCTV analytics pipeline.
"""
__version__ = "1.0.0"
__author__  = "Store Intelligence Team"

from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR     = PROJECT_ROOT / "data"
MODELS_DIR   = PROJECT_ROOT / "models"
LOGS_DIR     = PROJECT_ROOT / "logs"

for _dir in [DATA_DIR, MODELS_DIR, LOGS_DIR]:
    _dir.mkdir(parents=True, exist_ok=True)