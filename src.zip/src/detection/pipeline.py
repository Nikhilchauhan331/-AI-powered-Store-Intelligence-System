"""
Legacy detection pipeline — superseded by src/pipeline/pipeline.py.

Provides a `VideoPipeline` alias that points to the new `StorePipeline`
so any code that still does `from src.detection.pipeline import VideoPipeline`
continues to work without importing any broken old modules.
"""
try:
    from src.pipeline.pipeline import StorePipeline as VideoPipeline
except Exception:
    # Stub — used when pipeline deps (cv2, yaml, etc.) are unavailable
    class VideoPipeline:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs):
            pass
        def start_async(self):
            pass
        def stop(self):
            pass
        def get_status(self) -> dict:
            return {"is_running": False}

__all__ = ["VideoPipeline"]
