"""Detection module — YOLOv8-based person detection."""
from .detector import StoreDetector, ObjectDetector, Detection

# Aliases for backward compatibility
PersonDetector = StoreDetector
YOLODetector   = StoreDetector

__all__ = ["StoreDetector", "ObjectDetector", "PersonDetector", "YOLODetector", "Detection"]