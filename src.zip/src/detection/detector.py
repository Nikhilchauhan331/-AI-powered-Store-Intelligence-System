"""YOLOv8 Object Detector — conditional imports, zone support, pipeline-compatible API."""

import logging
import numpy as np
from typing import List, Tuple, Optional, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# ── Optional heavy imports ─────────────────────────────────────────

try:
    import cv2 as _cv2
    cv2 = _cv2
except ImportError:
    cv2 = None

try:
    from ultralytics import YOLO
except ImportError:
    YOLO = None
    logger.warning("ultralytics not installed — detector will return empty results")

try:
    from config.settings import settings as _settings
    _YOLO_MODEL     = _settings.yolo_model
    _CONFIDENCE     = _settings.confidence_threshold
    _IOU_THRESHOLD  = _settings.iou_threshold
except Exception:
    _YOLO_MODEL    = "yolov8n.pt"
    _CONFIDENCE    = 0.5
    _IOU_THRESHOLD = 0.45


# ── Detection dataclass ────────────────────────────────────────────

@dataclass
class Detection:
    """Single detection — supports both xyxy and xywh (normalised) bbox."""
    bbox: Tuple[float, float, float, float] = (0.0, 0.0, 0.0, 0.0)
    confidence: float   = 0.0
    class_id: int       = 0
    class_name: str     = "person"
    track_id: int       = 0
    zone_id: Optional[str]   = None
    zone_name: Optional[str] = None
    frame_number: int   = 0

    @property
    def center(self) -> Tuple[float, float]:
        x1, y1, x2, y2 = self.bbox
        return ((x1 + x2) / 2, (y1 + y2) / 2)

    @property
    def area(self) -> float:
        x1, y1, x2, y2 = self.bbox
        return (x2 - x1) * (y2 - y1)

    def to_tlwh(self) -> Tuple[float, float, float, float]:
        x1, y1, x2, y2 = self.bbox
        return (x1, y1, x2 - x1, y2 - y1)

    def to_dict(self) -> dict:
        return {
            "bbox_xyxy":  list(self.bbox),
            "bbox":       list(self.bbox),
            "confidence": round(self.confidence, 4),
            "class_id":   self.class_id,
            "class_name": self.class_name,
            "center":     list(self.center),
            "track_id":   self.track_id,
            "zone_id":    self.zone_id,
        }


# ── COCO names ────────────────────────────────────────────────────

COCO_NAMES: Dict[int, str] = {
    0: "person", 24: "backpack", 25: "umbrella", 26: "handbag",
    27: "tie", 28: "suitcase", 39: "bottle", 41: "cup",
    56: "chair", 62: "tv", 63: "laptop", 67: "cell phone",
}


# ── StoreDetector ─────────────────────────────────────────────────

class StoreDetector:
    """
    YOLOv8 detector + zone mapping.

    Accepts either:
      StoreDetector("config/config.yaml")           ← pipeline style
      StoreDetector(model_path="yolov8n.pt", ...)   ← direct style
    """

    def __init__(
        self,
        config_path: Optional[str] = None,
        model_path: Optional[str] = None,
        confidence_threshold: Optional[float] = None,
        iou_threshold: Optional[float] = None,
        device: str = "cpu",
        **kwargs,
    ):
        # ── Load from YAML config if provided ─────────────────────
        self._zones: List[Dict] = []          # list from config zones
        if config_path and config_path.endswith((".yaml", ".yml")):
            try:
                import yaml
                with open(config_path) as f:
                    cfg = yaml.safe_load(f)
                det = cfg.get("detection", {})
                model_path         = model_path or det.get("model", _YOLO_MODEL)
                confidence_threshold = confidence_threshold if confidence_threshold is not None \
                    else det.get("confidence", _CONFIDENCE)
                iou_threshold      = iou_threshold if iou_threshold is not None \
                    else det.get("iou_threshold", _IOU_THRESHOLD)
                device             = det.get("device", device)
                self._zones        = cfg.get("zones", [])
            except Exception as exc:
                logger.warning(f"Could not load config {config_path}: {exc}")

        self.model_path           = model_path or _YOLO_MODEL
        self.confidence_threshold = confidence_threshold if confidence_threshold is not None \
            else _CONFIDENCE
        self.iou_threshold        = iou_threshold if iou_threshold is not None \
            else _IOU_THRESHOLD
        self.device               = device
        self._model               = None
        self._initialized         = False

        if YOLO is not None:
            try:
                self._model = YOLO(self.model_path)
                self._model.to(self.device)
                self._initialized = True
                logger.info(f"YOLOv8 loaded: {self.model_path} on {self.device}")
            except Exception as exc:
                logger.warning(f"YOLOv8 load failed ({exc}) — stub mode")
        else:
            logger.info("ultralytics not installed — StoreDetector in stub mode")

    # ── Internal helpers ──────────────────────────────────────────

    def _parse_results(self, results, frame_h: int, frame_w: int) -> List[Dict]:
        dets = []
        for result in results:
            if result.boxes is None:
                continue
            for box in result.boxes:
                x1, y1, x2, y2 = (float(v) for v in box.xyxy[0].cpu().numpy())
                conf   = float(box.conf[0].cpu().numpy())
                cls_id = int(box.cls[0].cpu().numpy())
                cls_nm = COCO_NAMES.get(cls_id, f"class_{cls_id}")
                cx = (x1 + x2) / 2 / frame_w
                cy = (y1 + y2) / 2 / frame_h
                dets.append({
                    "bbox_xyxy":  [x1, y1, x2, y2],
                    "bbox":       [x1, y1, x2, y2],
                    "confidence": round(conf, 4),
                    "class_id":   cls_id,
                    "class_name": cls_nm,
                    "center":     [cx, cy],
                    "track_id":   0,
                    "zone_id":    None,
                    "zone_name":  None,
                })
        return dets

    # ── Public detection API ──────────────────────────────────────

    def detect(self, frame: np.ndarray) -> List[Dict]:
        """Run detection. Returns list of detection dicts."""
        if not self._initialized or self._model is None:
            return []
        try:
            h, w = frame.shape[:2]
            results = self._model.predict(
                frame, conf=self.confidence_threshold,
                iou=self.iou_threshold, classes=[0], verbose=False,
            )
            return self._parse_results(results, frame_h=h, frame_w=w)
        except Exception as exc:
            logger.error(f"detect() error: {exc}")
            return []

    def detect_annotated(self, frame: np.ndarray) -> Tuple[List[Dict], np.ndarray]:
        """Run detection and return (detections, annotated_frame)."""
        detections = self.detect(frame)
        annotated  = self.draw_detections(frame, detections)
        return detections, annotated

    # ── Drawing ───────────────────────────────────────────────────

    def draw_detections(
        self,
        frame: np.ndarray,
        detections: List[Dict],
        color: Tuple[int, int, int] = (0, 255, 0),
    ) -> np.ndarray:
        """Draw raw detection bboxes on a frame."""
        if cv2 is None:
            return frame
        annotated = frame.copy()
        for det in detections:
            bbox = det.get("bbox_xyxy") or det.get("bbox", [])
            if len(bbox) < 4:
                continue
            x1, y1, x2, y2 = map(int, bbox)
            cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
            label = f"{det.get('class_name', '?')} {det.get('confidence', 0):.2f}"
            cv2.putText(annotated, label, (x1, max(y1 - 5, 0)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
        return annotated

    def draw_tracks(
        self,
        frame: np.ndarray,
        det_objs: List[Detection],
        frame_w: int = 0,
        frame_h: int = 0,
    ) -> np.ndarray:
        """
        Draw confirmed track bboxes on a frame.
        det_objs use normalised xywh bbox (from pipeline step 4).
        """
        if cv2 is None or not det_objs:
            return frame
        h = frame_h or frame.shape[0]
        w = frame_w or frame.shape[1]
        annotated = frame.copy()
        for det in det_objs:
            nx, ny, nw, nh = det.bbox          # normalised xywh
            x1 = int(nx * w);   y1 = int(ny * h)
            x2 = int((nx + nw) * w); y2 = int((ny + nh) * h)
            color = (0, 255, 80)
            cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
            label = f"ID:{det.track_id}"
            if det.zone_name:
                label += f" [{det.zone_name}]"
            cv2.putText(annotated, label, (x1, max(y1 - 6, 0)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, color, 1)
        return annotated

    # ── Zone helpers ──────────────────────────────────────────────

    def get_zone_for_point(
        self,
        cx_norm: float,
        cy_norm: float,
        frame_w: int = 640,
        frame_h: int = 480,
    ) -> Tuple[Optional[str], Optional[str]]:
        """
        Return (zone_id, zone_name) for a normalised point (0-1).
        Uses polygon point-in-polygon test against zones from config.
        Returns (None, None) if point is not inside any zone.
        """
        if not self._zones or cv2 is None:
            return None, None

        px = cx_norm * frame_w
        py = cy_norm * frame_h

        for zone in self._zones:
            coords = zone.get("coordinates", [])
            if len(coords) < 3:
                continue
            polygon = np.array(coords, dtype=np.int32)
            if cv2.pointPolygonTest(polygon, (px, py), False) >= 0:
                return zone.get("id"), zone.get("name")
        return None, None

    def get_overcrowded_zones(self, det_objs: List[Detection]) -> List[Dict]:
        """
        Return list of zones that exceed their alert_capacity.
        Each entry: {zone_id, zone_name, count, capacity}
        Used by AnomalyDetector strategy 2.
        """
        if not self._zones:
            return []

        # Count persons per zone
        zone_counts: Dict[str, int] = {}
        for det in det_objs:
            if det.zone_id:
                zone_counts[det.zone_id] = zone_counts.get(det.zone_id, 0) + 1

        overcrowded = []
        for zone in self._zones:
            zid      = zone.get("id")
            capacity = zone.get("alert_capacity", 999)
            count    = zone_counts.get(zid, 0)
            if count > capacity:
                overcrowded.append({
                    "zone_id":   zid,
                    "zone_name": zone.get("name", zid),
                    "count":     count,
                    "capacity":  capacity,
                })
        return overcrowded

    # ── Static utilities ──────────────────────────────────────────

    @staticmethod
    def _calculate_center(bbox: List[float]) -> Tuple[float, float]:
        x1, y1, x2, y2 = bbox
        return ((x1 + x2) / 2, (y1 + y2) / 2)

    @staticmethod
    def _calculate_iou(b1: List[float], b2: List[float]) -> float:
        ix1 = max(b1[0], b2[0]); iy1 = max(b1[1], b2[1])
        ix2 = min(b1[2], b2[2]); iy2 = min(b1[3], b2[3])
        inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
        a1 = (b1[2] - b1[0]) * (b1[3] - b1[1])
        a2 = (b2[2] - b2[0]) * (b2[3] - b2[1])
        union = a1 + a2 - inter
        return inter / union if union > 0 else 0.0


# ── Aliases ───────────────────────────────────────────────────────
PersonDetector = StoreDetector
YOLODetector   = StoreDetector


# ── ObjectDetector — backward-compat wrapper ──────────────────────

class ObjectDetector(StoreDetector):
    """
    Legacy name — detect() returns List[Detection] objects instead of dicts.
    """

    def detect(self, frame: np.ndarray) -> List[Detection]:  # type: ignore[override]
        raw = super().detect(frame)
        return [
            Detection(
                bbox=tuple(d["bbox_xyxy"]),   # type: ignore[arg-type]
                confidence=d["confidence"],
                class_id=d["class_id"],
                class_name=d["class_name"],
            )
            for d in raw
        ]

    def detect_batch(self, frames: List[np.ndarray]) -> List[List[Detection]]:
        return [self.detect(f) for f in frames]

    def annotate_frame(
        self,
        frame: np.ndarray,
        detections: List[Detection],
        color: Tuple[int, int, int] = (0, 255, 0),
    ) -> np.ndarray:
        dicts = [d.to_dict() for d in detections]
        return self.draw_detections(frame, dicts, color)
