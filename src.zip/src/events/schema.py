"""Event schema definitions for the Store Intelligence System."""

import uuid
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field, asdict
from enum import Enum


class EventType(str, Enum):
    PERSON_DETECTED = "PERSON_DETECTED"
    ZONE_ENTRY = "ZONE_ENTRY"
    ZONE_EXIT = "ZONE_EXIT"
    LOITERING = "LOITERING"
    OVERCROWDING = "OVERCROWDING"
    SPEED_ANOMALY = "SPEED_ANOMALY"
    OFF_HOURS_ACTIVITY = "OFF_HOURS_ACTIVITY"
    ANALYTICS_SNAPSHOT = "ANALYTICS_SNAPSHOT"
    ZONE_DWELL_ALERT = "ZONE_DWELL_ALERT"


@dataclass
class StoreEvent:
    event_id: str
    event_type: EventType
    timestamp: str
    camera_id: str
    version: str = "1.0"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["event_type"] = self.event_type.value
        return d


@dataclass
class DetectionEvent(StoreEvent):
    track_id: int = 0
    bbox: List[float] = field(default_factory=list)
    confidence: float = 0.0
    class_name: str = "person"
    center: List[float] = field(default_factory=list)
    zone_id: Optional[str] = None
    dwell_time_seconds: float = 0.0
    speed: float = 0.0


@dataclass
class AnomalyEvent(StoreEvent):
    anomaly_type: str = ""
    severity: str = "medium"
    description: str = ""
    affected_tracks: List[int] = field(default_factory=list)
    zone_id: Optional[str] = None
    threshold: float = 0.0
    actual_value: float = 0.0


@dataclass
class AnalyticsSnapshot(StoreEvent):
    active_count: int = 0
    total_footfall: int = 0
    zone_counts: Dict[str, int] = field(default_factory=dict)
    avg_dwell_time: float = 0.0
    fps: float = 0.0


class EventFactory:
    def __init__(self, camera_id: str):
        self.camera_id = camera_id

    def create_detection_event(self, track, timestamp: str) -> dict:
        return DetectionEvent(
            event_id=str(uuid.uuid4()), event_type=EventType.PERSON_DETECTED,
            timestamp=timestamp, camera_id=self.camera_id, track_id=track.track_id,
            bbox=list(track.bbox), confidence=track.confidence, class_name=track.class_name,
            center=list(track.center), zone_id=track.zone_id,
            dwell_time_seconds=track.age_seconds, speed=track.speed,
        ).to_dict()

    def create_anomaly_event(self, anomaly: dict, timestamp: str) -> dict:
        return AnomalyEvent(
            event_id=str(uuid.uuid4()), event_type=EventType(anomaly["type"]),
            timestamp=timestamp, camera_id=self.camera_id, anomaly_type=anomaly["type"],
            severity=anomaly.get("severity", "medium"), description=anomaly.get("description", ""),
            affected_tracks=anomaly.get("track_ids", []), zone_id=anomaly.get("zone_id"),
            threshold=anomaly.get("threshold", 0), actual_value=anomaly.get("actual_value", 0),
        ).to_dict()

    def create_analytics_snapshot(self, analytics_data: dict) -> dict:
        return AnalyticsSnapshot(
            event_id=str(uuid.uuid4()), event_type=EventType.ANALYTICS_SNAPSHOT,
            timestamp=datetime.now(timezone.utc).isoformat(), camera_id=self.camera_id,
            **analytics_data,
        ).to_dict()