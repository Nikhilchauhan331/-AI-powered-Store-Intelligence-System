"""Kafka event consumer for processing and persisting events."""

import json
import structlog
from kafka import KafkaConsumer
from kafka.errors import KafkaError
from typing import Callable, List, Optional
from config.settings import settings

logger = structlog.get_logger()


class EventConsumer:
    def __init__(self, topics=None, group_id=None):
        self.topics = topics or [
            settings.kafka_topic_detections,
            settings.kafka_topic_analytics,
            settings.kafka_topic_anomalies,
        ]
        self.group_id = group_id or settings.kafka_group_id
        self.handlers = {}
        self.is_running = False

        self.consumer = KafkaConsumer(
            *self.topics, bootstrap_servers=settings.kafka_bootstrap_servers,
            group_id=self.group_id,
            value_deserializer=lambda m: json.loads(m.decode("utf-8")),
            auto_offset_reset="latest", enable_auto_commit=True,
        )

    def register_handler(self, topic: str, handler: Callable):
        self.handlers[topic] = handler

    def consume(self):
        self.is_running = True
        try:
            for message in self.consumer:
                if not self.is_running:
                    break
                handler = self.handlers.get(message.topic)
                if handler:
                    try:
                        handler(message.value)
                    except Exception as e:
                        logger.error(f"Handler error: {e}")
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()

    def stop(self):
        self.is_running = False
        self.consumer.close()