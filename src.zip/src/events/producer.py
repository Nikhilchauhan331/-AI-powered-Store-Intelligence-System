"""Kafka event producer with reliability guarantees."""

import json
import structlog
from kafka import KafkaProducer
from kafka.errors import KafkaError
from config.settings import settings

logger = structlog.get_logger()


class EventProducer:
    def __init__(self):
        try:
            self.producer = KafkaProducer(
                bootstrap_servers=settings.kafka_bootstrap_servers,
                value_serializer=lambda v: json.dumps(v).encode("utf-8"),
                key_serializer=lambda k: k.encode("utf-8") if k else None,
                acks="all", retries=3, retry_backoff_ms=500, max_block_ms=5000,
                linger_ms=10, batch_size=16384, compression_type="gzip",
            )
            self._connected = True
        except KafkaError as e:
            self._connected = False
            raise

    def send_detection(self, event: dict):
        self._send(settings.kafka_topic_detections, event.get("camera_id", "unknown"), event)

    def send_anomaly(self, event: dict):
        self._send(settings.kafka_topic_anomalies, event.get("camera_id", "unknown"), event)

    def send_analytics(self, snapshot: dict):
        self._send(settings.kafka_topic_analytics, snapshot.get("camera_id", "unknown"), snapshot)

    def _send(self, topic, key, value):
        if not self._connected:
            return
        try:
            self.producer.send(topic, key=key, value=value)
        except KafkaError as e:
            logger.error(f"Failed to send event to {topic}: {e}")

    def flush(self):
        if self._connected:
            self.producer.flush()

    def close(self):
        if self._connected:
            self.producer.flush()
            self.producer.close()