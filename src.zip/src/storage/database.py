"""
PostgreSQL connection manager using SQLAlchemy + asyncpg.
Provides DatabaseManager for the API lifespan and sync psycopg2
for scripts/migrations.
"""
import logging
import os
from typing import Optional

from sqlalchemy.ext.asyncio import (
    create_async_engine, AsyncSession, async_sessionmaker
)
from sqlalchemy.orm import DeclarativeBase

logger = logging.getLogger(__name__)


# ── ORM Base ──────────────────────────────────────────────────────
class Base(DeclarativeBase):
    pass


# ── Async engine (shared) ─────────────────────────────────────────
_DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+asyncpg://store_user:store_password@localhost:5432/store_intelligence",
)

engine = create_async_engine(
    _DATABASE_URL,
    echo=False,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
)
async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def get_session():
    async with async_session() as session:
        yield session


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


# ── DatabaseManager — used by api/main.py lifespan ────────────────
class DatabaseManager:
    """
    Thin wrapper around psycopg2 for synchronous health-check / script use.
    The API uses the async SQLAlchemy session above for actual queries.
    """

    def __init__(self):
        self.host     = os.getenv("DB_HOST",     "localhost")
        self.port     = int(os.getenv("DB_PORT", "5432"))
        self.name     = os.getenv("DB_NAME",     "store_intelligence")
        self.user     = os.getenv("DB_USER",     "store_user")
        self.password = os.getenv("DB_PASSWORD", "store_password")
        self._conn    = None

    def connect(self) -> bool:
        try:
            import psycopg2
            self._conn = psycopg2.connect(
                host=self.host, port=self.port,
                dbname=self.name, user=self.user, password=self.password,
                connect_timeout=5,
            )
            logger.info(f"PostgreSQL connected: {self.host}:{self.port}/{self.name}")
            return True
        except Exception as e:
            logger.error(f"DB connect failed: {e}")
            return False

    def close(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None
            logger.info("PostgreSQL connection closed")

    def ping(self) -> bool:
        try:
            if self._conn:
                cur = self._conn.cursor()
                cur.execute("SELECT 1")
                cur.close()
                return True
        except Exception:
            pass
        return False

    def execute(self, sql: str, params=None):
        """Run a single SQL statement (for scripts / health checks)."""
        if not self._conn:
            return None
        try:
            cur = self._conn.cursor()
            cur.execute(sql, params or ())
            self._conn.commit()
            return cur
        except Exception as e:
            logger.error(f"SQL error: {e}")
            self._conn.rollback()
            return None
