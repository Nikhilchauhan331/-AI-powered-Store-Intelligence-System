"""
Redis cache manager — real-time state, ring-buffer events, counters.
"""
import os, json, logging
from typing import Optional, Dict, Any, List

import redis

logger = logging.getLogger(__name__)


class CacheManager:

    def __init__(self, host=None, port=None, db=0,
                 password=None, prefix="si"):
        self.host     = host     or os.getenv("REDIS_HOST",     "localhost")
        self.port     = port     or int(os.getenv("REDIS_PORT", "6379"))
        self.db       = db
        self.password = password or os.getenv("REDIS_PASSWORD", None)
        self.prefix   = prefix
        self._client: Optional[redis.Redis] = None
        self._warned_unavailable = False

    def connect(self) -> bool:
        try:
            self._client = redis.Redis(
                host=self.host, port=self.port, db=self.db,
                password=self.password, decode_responses=True,
                socket_timeout=5, retry_on_timeout=True,
            )
            self._client.ping()
            logger.info(f"Redis connected: {self.host}:{self.port}")
            return True
        except Exception as e:
            logger.error(f"Redis connect failed: {e}")
            return False

    def _key(self, *parts: str) -> str:
        return f"{self.prefix}:{':'.join(parts)}"

    def _is_connected(self) -> bool:
        return self._client is not None

    def _warn_unavailable(self):
        if not self._warned_unavailable:
            logger.warning("Redis unavailable — cache operations will be skipped")
            self._warned_unavailable = True

    # ── Current Count ─────────────────────────────────────
    def set_current_count(self, camera_id: str, count: int, ttl=30):
        if not self._is_connected():
            self._warn_unavailable()
            return
        self._client.setex(self._key("count", camera_id), ttl, count)

    def get_current_count(self, camera_id: str) -> int:
        if not self._is_connected():
            return 0
        v = self._client.get(self._key("count", camera_id))
        return int(v) if v else 0

    # ── Zone Counts ───────────────────────────────────────
    def set_zone_counts(self, zones: Dict[str, int], ttl=30):
        if not self._is_connected():
            self._warn_unavailable()
            return
        self._client.setex(self._key("zones"), ttl, json.dumps(zones))

    def get_zone_counts(self) -> Dict[str, int]:
        if not self._is_connected():
            return {}
        v = self._client.get(self._key("zones"))
        return json.loads(v) if v else {}

    # ── Track State ───────────────────────────────────────
    def set_track(self, track_id: int, data: Dict[str, Any], ttl=120):
        if not self._is_connected():
            self._warn_unavailable()
            return
        self._client.setex(self._key("track", str(track_id)), ttl,
                           json.dumps(data, default=str))

    def get_track(self, track_id: int) -> Optional[Dict]:
        if not self._is_connected():
            return None
        v = self._client.get(self._key("track", str(track_id)))
        return json.loads(v) if v else None

    def get_active_track_ids(self) -> List[int]:
        if not self._is_connected():
            return []
        keys = self._client.keys(self._key("track", "*"))
        return [int(k.split(":")[-1]) for k in keys]

    # ── Event Ring Buffer ─────────────────────────────────
    def push_event(self, event: Dict[str, Any], max_size=500):
        if not self._is_connected():
            self._warn_unavailable()
            return
        key = self._key("events")
        self._client.lpush(key, json.dumps(event, default=str))
        self._client.ltrim(key, 0, max_size - 1)

    def get_recent_events(self, count=50) -> List[Dict]:
        if not self._is_connected():
            return []
        return [json.loads(i) for i in
                self._client.lrange(self._key("events"), 0, count - 1)]

    # ── Anomaly Cache ─────────────────────────────────────
    def set_anomaly(self, anomaly_id: str, data: Dict[str, Any], ttl=300):
        if not self._is_connected():
            self._warn_unavailable()
            return
        self._client.setex(self._key("anomaly", anomaly_id), ttl,
                           json.dumps(data, default=str))

    def get_active_anomalies(self) -> List[Dict]:
        if not self._is_connected():
            return []
        result = []
        for key in self._client.keys(self._key("anomaly", "*")):
            v = self._client.get(key)
            if v: result.append(json.loads(v))
        return result

    # ── Counters ──────────────────────────────────────────
    def increment_counter(self, name: str) -> int:
        if not self._is_connected():
            self._warn_unavailable()
            return 0
        return self._client.incr(self._key("counter", name))

    def get_counter(self, name: str) -> int:
        if not self._is_connected():
            return 0
        v = self._client.get(self._key("counter", name))
        return int(v) if v else 0

    # ── Utility ───────────────────────────────────────────
    def ping(self) -> bool:
        if not self._is_connected():
            return False
        try:    return self._client.ping()
        except: return False

    def flush(self):
        if not self._is_connected():
            return
        keys = self._client.keys(self._key("*"))
        if keys: self._client.delete(*keys)

    def close(self):
        if self._client:
            self._client.close()
            logger.info("Redis closed")

    # ── Pipeline convenience methods ──────────────────────
    def push_anomaly(self, data: Dict[str, Any], ttl: int = 300):
        """Store anomaly by its event_id and push to event ring buffer."""
        anomaly_id = data.get("event_id", data.get("anomaly_id", "unknown"))
        self.set_anomaly(anomaly_id, data, ttl=ttl)
        self.push_event(data)

    def set_analytics(self, camera_id: str, snap: Dict[str, Any], ttl: int = 60):
        """Cache a full analytics snapshot for a camera."""
        if not self._is_connected():
            return
        key = self._key("analytics", camera_id)
        self._client.setex(key, ttl, json.dumps(snap, default=str))

    def get_analytics(self, camera_id: str) -> Optional[Dict]:
        if not self._is_connected():
            return None
        v = self._client.get(self._key("analytics", camera_id))
        return json.loads(v) if v else None


# Alias for pipeline.py compatibility
RedisClient = CacheManager