import uuid
from typing import List, Optional
from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession
from src.storage.models import DetectionRecord, AnomalyRecord


class DetectionRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def save_detection(self, event):
        record = DetectionRecord(
            event_id=event.get("event_id", str(uuid.uuid4())),
            camera_id=event["camera_id"], track_id=event["track_id"],
            bbox=event.get("bbox"), confidence=event.get("confidence", 0),
            class_name=event.get("class_name", "person"), zone_id=event.get("zone_id"),
            dwell_time=event.get("dwell_time_seconds", 0), speed=event.get("speed", 0),
        )
        self.session.add(record)
        await self.session.commit()

    async def get_detections(self, camera_id=None, limit=100):
        query = select(DetectionRecord).order_by(desc(DetectionRecord.timestamp))
        if camera_id:
            query = query.where(DetectionRecord.camera_id == camera_id)
        result = await self.session.execute(query.limit(limit))
        return result.scalars().all()


class AnomalyRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def save_anomaly(self, event):
        record = AnomalyRecord(
            event_id=event.get("event_id", str(uuid.uuid4())),
            camera_id=event["camera_id"], anomaly_type=event["type"],
            severity=event.get("severity", "medium"), description=event.get("description", ""),
            affected_tracks=event.get("track_ids", []), zone_id=event.get("zone_id"),
            threshold=event.get("threshold", 0), actual_value=event.get("actual_value", 0),
        )
        self.session.add(record)
        await self.session.commit()

    async def get_anomalies(self, anomaly_type=None, severity=None, limit=50):
        query = select(AnomalyRecord).order_by(desc(AnomalyRecord.timestamp))
        if anomaly_type:
            query = query.where(AnomalyRecord.anomaly_type == anomaly_type)
        if severity:
            query = query.where(AnomalyRecord.severity == severity)
        result = await self.session.execute(query.limit(limit))
        return result.scalars().all()