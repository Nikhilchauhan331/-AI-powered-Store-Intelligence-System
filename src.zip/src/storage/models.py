from sqlalchemy import Column, Integer, String, Float, DateTime, JSON, Boolean, Index
from sqlalchemy.sql import func
from src.storage.database import Base


class DetectionRecord(Base):
    __tablename__ = "detections"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(String(36), unique=True, nullable=False, index=True)
    camera_id = Column(String(50), nullable=False, index=True)
    track_id = Column(Integer, nullable=False)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    bbox = Column(JSON)
    confidence = Column(Float)
    class_name = Column(String(50))
    zone_id = Column(String(50))
    dwell_time = Column(Float, default=0.0)
    speed = Column(Float, default=0.0)
    metadata_ = Column("metadata", JSON, default={})
    __table_args__ = (Index("idx_camera_timestamp", "camera_id", "timestamp"),)


class AnomalyRecord(Base):
    __tablename__ = "anomalies"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(String(36), unique=True, nullable=False)
    camera_id = Column(String(50), nullable=False, index=True)
    anomaly_type = Column(String(50), nullable=False, index=True)
    severity = Column(String(20), nullable=False)
    description = Column(String(500))
    affected_tracks = Column(JSON)
    zone_id = Column(String(50))
    threshold = Column(Float)
    actual_value = Column(Float)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    resolved = Column(Boolean, default=False)


class FootfallRecord(Base):
    __tablename__ = "footfall"
    id = Column(Integer, primary_key=True, autoincrement=True)
    camera_id = Column(String(50), nullable=False)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    count = Column(Integer, default=0)
    zone_counts = Column(JSON, default={})
    hour = Column(Integer)
    date = Column(String(10))
    __table_args__ = (Index("idx_footfall_date_hour", "date", "hour"),)