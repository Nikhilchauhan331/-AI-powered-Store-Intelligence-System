import json
import redis
import structlog
from typing import Optional
from config.settings import settings

logger = structlog.get_logger()


class RedisCache:
    def __init__(self):
        try:
            self.client = redis.Redis(host=settings.redis_host, port=settings.redis_port,
                                      db=settings.redis_db, decode_responses=True, socket_connect_timeout=5)
            self.client.ping()
            self._connected = True
        except redis.ConnectionError:
            self._connected = False

    def ping(self):
        try:
            return self._connected and self.client.ping()
        except Exception:
            return False

    def set_active_count(self, count):
        if self._connected:
            self.client.set("store:active_count", count, ex=30)

    def get_active_count(self):
        if not self._connected:
            return 0
        val = self.client.get("store:active_count")
        return int(val) if val else 0

    def set_analytics_snapshot(self, snapshot):
        if self._connected:
            self.client.set("store:analytics:snapshot", json.dumps(snapshot), ex=60)

    def get_analytics_snapshot(self):
        if not self._connected:
            return None
        val = self.client.get("store:analytics:snapshot")
        return json.loads(val) if val else None

    def push_anomaly(self, anomaly):
        if self._connected:
            self.client.lpush("store:anomalies:recent", json.dumps(anomaly))
            self.client.ltrim("store:anomalies:recent", 0, 99)

    def get_recent_anomalies(self, limit=20):
        if not self._connected:
            return []
        items = self.client.lrange("store:anomalies:recent", 0, limit - 1)
        return [json.loads(item) for item in items]

    def close(self):
        if self._connected:
            self.client.close()