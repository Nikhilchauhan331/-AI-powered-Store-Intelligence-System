"""Anomaly detection — loitering, overcrowding, speed, off-hours."""
from .anomaly_detector import AnomalyDetector
__all__ = ["AnomalyDetector"]