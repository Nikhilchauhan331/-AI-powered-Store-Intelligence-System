"""
Five-strategy anomaly detector with deduplication.

Strategy 1: Loitering         — person stationary > threshold seconds
Strategy 2: Overcrowding      — zone exceeds its alert_capacity
Strategy 3: Speed Anomaly     — person moving N× faster than rolling baseline
Strategy 4: Off-Hours Activity— any detections during store closed hours
Strategy 5: Zone Dwell Alert  — person in a specific zone > dwell threshold
"""
import time
from datetime import datetime
from typing import List, Dict, Any, Optional
from collections import defaultdict
import yaml
from loguru import logger

from src.streaming.event_schema import AnomalyEvent, AnomalyType, Severity


class AnomalyDetector:

    def __init__(self, config_path: str = "config/config.yaml"):
        with open(config_path) as f:
            config = yaml.safe_load(f)

        an = config.get("anomaly", {})
        self.loitering_threshold  = an.get("loitering_threshold_seconds", 30)
        self.crowd_threshold      = an.get("crowd_threshold", 10)
        self.speed_multiplier     = an.get("speed_multiplier_threshold", 3.0)
        self.dwell_threshold      = an.get("dwell_time_threshold_seconds", 120)
        self.off_hours_start      = an.get("off_hours_start", 22)
        self.off_hours_end        = an.get("off_hours_end", 6)

        # Deduplication: emit same anomaly at most once per _dedup_window seconds
        self._dedup: Dict[str, float] = {}
        self._dedup_window = 30.0

        # Rolling speed baseline (exponential moving avg)
        self._speed_ema    = 0.0
        self._speed_alpha  = 0.05   # smoothing factor
        self._speed_warmup = 0      # frames before baseline is trusted

        logger.info(
            f"AnomalyDetector ready | loitering>{self.loitering_threshold}s "
            f"crowd>{self.crowd_threshold} speed>{self.speed_multiplier}x"
        )

    def detect(
        self,
        detections:  List[Dict],
        tracker,
        detector,
        camera_id:   str,
        store_id:    str,
        timestamp:   datetime,
    ) -> List[AnomalyEvent]:
        results: List[AnomalyEvent] = []
        results += self._check_loitering(detections, tracker, camera_id, store_id, timestamp)
        results += self._check_overcrowding(detections, detector, camera_id, store_id, timestamp)
        results += self._check_speed(detections, camera_id, store_id, timestamp)
        results += self._check_off_hours(detections, camera_id, store_id, timestamp)
        results += self._check_zone_dwell(detections, tracker, camera_id, store_id, timestamp)
        return results

    # ── Strategy 1: Loitering ─────────────────────────────────────

    def _check_loitering(self, detections, tracker, camera_id, store_id, ts) -> List[AnomalyEvent]:
        out = []
        for det in detections:
            tid   = det["track_id"]
            state = tracker.get_track_state(tid)
            if not state or state.dwell_time < self.loitering_threshold:
                continue
            key = f"{AnomalyType.LOITERING}:{tid}"
            if not self._should_emit(key):
                continue
            sev = (Severity.HIGH
                   if state.dwell_time > self.loitering_threshold * 3
                   else Severity.MEDIUM)
            out.append(AnomalyEvent(
                camera_id=camera_id, store_id=store_id,
                anomaly_type=AnomalyType.LOITERING, severity=sev,
                description=(
                    f"Person ID {tid} has been stationary for "
                    f"{state.dwell_time:.0f}s (threshold={self.loitering_threshold}s)"
                ),
                track_id=tid, zone_id=det.get("zone_id"),
                metadata={"dwell_time": round(state.dwell_time, 1),
                          "threshold": self.loitering_threshold},
            ))
        return out

    # ── Strategy 2: Overcrowding ──────────────────────────────────

    def _check_overcrowding(self, detections, detector, camera_id, store_id, ts) -> List[AnomalyEvent]:
        from src.detection.detector import Detection
        det_objs = [
            Detection(
                track_id=d["track_id"],
                bbox=d["bbox_norm"],
                confidence=d.get("confidence", 0.5),
                zone_id=d.get("zone_id"),
                zone_name=d.get("zone_name"),
                frame_number=0,
            )
            for d in detections
        ]
        overcrowded = detector.get_overcrowded_zones(det_objs)
        out = []
        for z in overcrowded:
            key = f"{AnomalyType.OVERCROWDING}:{z['zone_id']}"
            if not self._should_emit(key):
                continue
            ratio = z["count"] / max(z["capacity"], 1)
            sev   = Severity.CRITICAL if ratio >= 2.0 else Severity.HIGH
            out.append(AnomalyEvent(
                camera_id=camera_id, store_id=store_id,
                anomaly_type=AnomalyType.OVERCROWDING, severity=sev,
                description=(
                    f"Zone '{z['zone_name']}' overcrowded: "
                    f"{z['count']} people (capacity={z['capacity']})"
                ),
                zone_id=z["zone_id"], metadata=z,
            ))
        return out

    # ── Strategy 3: Speed Anomaly ─────────────────────────────────

    def _check_speed(self, detections, camera_id, store_id, ts) -> List[AnomalyEvent]:
        speeds = [d.get("speed", 0.0) for d in detections if d.get("speed", 0) > 1e-5]
        if speeds:
            frame_avg = sum(speeds) / len(speeds)
            if self._speed_warmup < 30:
                # Simple seed during warmup
                self._speed_ema = frame_avg if self._speed_ema == 0 else (
                    self._speed_alpha * frame_avg + (1 - self._speed_alpha) * self._speed_ema
                )
                self._speed_warmup += 1
            else:
                self._speed_ema = (
                    self._speed_alpha * frame_avg +
                    (1 - self._speed_alpha) * self._speed_ema
                )

        out = []
        if self._speed_warmup < 30 or self._speed_ema < 1e-6:
            return out   # Not enough data yet

        threshold = self._speed_ema * self.speed_multiplier
        for det in detections:
            speed = det.get("speed", 0.0)
            tid   = det["track_id"]
            if speed <= threshold:
                continue
            key = f"{AnomalyType.SPEED_ANOMALY}:{tid}"
            if not self._should_emit(key):
                continue
            out.append(AnomalyEvent(
                camera_id=camera_id, store_id=store_id,
                anomaly_type=AnomalyType.SPEED_ANOMALY, severity=Severity.MEDIUM,
                description=(
                    f"Person ID {tid} moving abnormally fast "
                    f"(speed={speed:.5f}, baseline={self._speed_ema:.5f}, "
                    f"threshold={threshold:.5f})"
                ),
                track_id=tid, zone_id=det.get("zone_id"),
                metadata={"speed": speed, "baseline": self._speed_ema,
                          "threshold": threshold},
            ))
        return out

    # ── Strategy 4: Off-Hours Activity ────────────────────────────

    def _check_off_hours(self, detections, camera_id, store_id, ts) -> List[AnomalyEvent]:
        if not detections:
            return []
        hour = ts.hour
        is_closed = (hour >= self.off_hours_start or hour < self.off_hours_end)
        if not is_closed:
            return []
        key = f"{AnomalyType.OFF_HOURS_ACTIVITY}:{camera_id}:{ts.strftime('%Y%m%d%H')}"
        if not self._should_emit(key):
            return []
        return [AnomalyEvent(
            camera_id=camera_id, store_id=store_id,
            anomaly_type=AnomalyType.OFF_HOURS_ACTIVITY, severity=Severity.HIGH,
            description=(
                f"Activity detected during off-hours at "
                f"{ts.strftime('%H:%M UTC')} — {len(detections)} person(s) visible"
            ),
            metadata={"hour": hour, "person_count": len(detections),
                      "off_hours_start": self.off_hours_start,
                      "off_hours_end": self.off_hours_end},
        )]

    # ── Strategy 5: Zone Dwell Alert ──────────────────────────────

    def _check_zone_dwell(self, detections, tracker, camera_id, store_id, ts) -> List[AnomalyEvent]:
        out = []
        for det in detections:
            tid     = det["track_id"]
            zone_id = det.get("zone_id")
            if not zone_id:
                continue
            state = tracker.get_track_state(tid)
            if not state or state.dwell_time < self.dwell_threshold:
                continue
            key = f"{AnomalyType.ZONE_DWELL}:{tid}:{zone_id}"
            if not self._should_emit(key):
                continue
            out.append(AnomalyEvent(
                camera_id=camera_id, store_id=store_id,
                anomaly_type=AnomalyType.ZONE_DWELL, severity=Severity.MEDIUM,
                description=(
                    f"Person ID {tid} has dwelled in zone "
                    f"'{det.get('zone_name', zone_id)}' for "
                    f"{state.dwell_time:.0f}s (threshold={self.dwell_threshold}s)"
                ),
                track_id=tid, zone_id=zone_id,
                metadata={"dwell_time": round(state.dwell_time, 1),
                          "threshold": self.dwell_threshold},
            ))
        return out

    # ── Deduplication ─────────────────────────────────────────────

    def _should_emit(self, key: str) -> bool:
        now = time.time()
        if key in self._dedup and now - self._dedup[key] < self._dedup_window:
            return False
        self._dedup[key] = now
        # Purge stale keys to prevent unbounded growth
        if len(self._dedup) > 10_000:
            stale = [k for k, t in self._dedup.items() if now - t > self._dedup_window * 2]
            for k in stale:
                del self._dedup[k]
        return True

    # ── Test-compatible stub-style methods ────────────────────────

    def detect_loitering(
        self, history: Dict[int, Dict], threshold_seconds: float = 60
    ) -> List[Dict]:
        """
        Detect loitering from a history dict:
          {track_id: {"first_seen": datetime, "last_seen": datetime, "zone": str, ...}}
        """
        results = []
        for tid, info in history.items():
            duration = (info["last_seen"] - info["first_seen"]).total_seconds()
            if duration >= threshold_seconds:
                sev = "high" if duration >= threshold_seconds * 3 else "medium"
                results.append({
                    "type":             "loitering",
                    "track_id":         tid,
                    "zone":             info.get("zone"),
                    "severity":         sev,
                    "duration_seconds": duration,
                })
        return results

    def detect_overcrowding(
        self, zone_counts: Dict[str, int], thresholds: Dict[str, int]
    ) -> List[Dict]:
        """Detect zones where count exceeds threshold."""
        results = []
        for zone, count in zone_counts.items():
            limit = thresholds.get(zone, 999)
            if count > limit:
                ratio = count / max(limit, 1)
                results.append({
                    "type":     "overcrowding",
                    "zone":     zone,
                    "count":    count,
                    "limit":    limit,
                    "severity": "critical" if ratio >= 2.0 else "high",
                })
        return results

    def detect_speed_anomalies(
        self, history: Dict[int, Dict], speed_threshold: float = 300
    ) -> List[Dict]:
        """
        Detect speed anomalies from history dict:
          {track_id: {"positions": [(x,y), ...], "timestamps": [datetime, ...], ...}}
        """
        results = []
        for tid, info in history.items():
            pos = info.get("positions", [])
            ts  = info.get("timestamps", [])
            if len(pos) >= 2 and len(ts) >= 2:
                dx = pos[-1][0] - pos[0][0]
                dy = pos[-1][1] - pos[0][1]
                dt = max((ts[-1] - ts[0]).total_seconds(), 0.001)
                speed = (dx**2 + dy**2) ** 0.5 / dt
                if speed > speed_threshold:
                    results.append({"type": "speed", "track_id": tid, "speed": speed})
        return results

    def detect_off_hours_activity(
        self,
        tracks: List,
        timestamp: datetime,
        open_hour: int = 8,
        close_hour: int = 22,
    ) -> List[Dict]:
        """Detect any detections outside business hours."""
        if not tracks:
            return []
        h = timestamp.hour
        if not (open_hour <= h < close_hour):
            return [{"type": "off_hours", "hour": h,
                     "track_count": len(tracks), "severity": "high"}]
        return []