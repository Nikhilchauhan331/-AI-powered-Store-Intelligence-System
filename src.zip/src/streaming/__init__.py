"""Streaming module — Kafka event producer/consumer and schema definitions."""
from .kafka_producer import EventProducer
from .kafka_consumer import EventConsumer
from .event_schema   import StoreEvent, EventType
__all__ = ["EventProducer", "EventConsumer", "StoreEvent", "EventType"]