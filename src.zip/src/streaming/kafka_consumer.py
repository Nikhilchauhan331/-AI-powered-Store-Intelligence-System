"""
Threaded Kafka consumer with per-topic handlers and graceful shutdown.
"""
import json
import logging
import threading
from typing import Optional, Dict, List, Callable, Any
from kafka import KafkaConsumer as _KafkaConsumer
from kafka.errors import NoBrokersAvailable

logger = logging.getLogger(__name__)


class EventConsumer:
    """Threaded Kafka consumer for Store Intelligence events."""

    def __init__(
        self,
        bootstrap_servers: str = "localhost:9092",
        group_id: str = "store-intelligence-consumer",
        topic_prefix: str = "store-intelligence",
        auto_offset_reset: str = "latest",
    ):
        self.bootstrap_servers = bootstrap_servers
        self.group_id          = group_id
        self.topic_prefix      = topic_prefix
        self.auto_offset_reset = auto_offset_reset
        self._consumer: Optional[_KafkaConsumer] = None
        self._handlers: Dict[str, List[Callable]] = {}
        self._running       = False
        self._thread: Optional[threading.Thread] = None
        self._message_count = 0
        self._error_count   = 0

    # ── Handler Registration ──────────────────────────────
    def register_handler(self, topic_suffix: str, handler: Callable):
        full_topic = f"{self.topic_prefix}.{topic_suffix}"
        self._handlers.setdefault(full_topic, []).append(handler)
        logger.info(f"Handler registered for {full_topic}")

    # ── Connection ────────────────────────────────────────
    def connect(self, topics: Optional[List[str]] = None) -> bool:
        subscribe_topics = topics or list(self._handlers.keys())
        if not subscribe_topics:
            subscribe_topics = [
                f"{self.topic_prefix}.{s}"
                for s in ("detections", "tracking", "anomalies", "analytics", "entry-exit")
            ]
        try:
            self._consumer = _KafkaConsumer(
                *subscribe_topics,
                bootstrap_servers=self.bootstrap_servers,
                group_id=self.group_id,
                auto_offset_reset=self.auto_offset_reset,
                enable_auto_commit=True,
                auto_commit_interval_ms=5000,
                value_deserializer=lambda m: json.loads(m.decode("utf-8")),
                consumer_timeout_ms=1000,
                max_poll_records=100,
            )
            logger.info(f"Consumer subscribed to {subscribe_topics}")
            return True
        except NoBrokersAvailable:
            logger.error("No Kafka brokers available")
            return False
        except Exception as e:
            logger.error(f"Consumer connect error: {e}")
            return False

    # ── Consume Loop ──────────────────────────────────────
    def _consume_loop(self):
        while self._running:
            try:
                if not self._consumer:
                    break
                for message in self._consumer:
                    if not self._running:
                        break
                    self._process_message(message)
            except StopIteration:
                continue
            except Exception as e:
                logger.error(f"Consume loop error: {e}")
                self._error_count += 1

    def _process_message(self, message):
        try:
            topic = message.topic
            data  = message.value
            self._message_count += 1

            for handler in self._handlers.get(topic, []):
                try:
                    handler(data)
                except Exception as e:
                    logger.error(f"Handler error ({topic}): {e}")
                    self._error_count += 1

            for handler in self._handlers.get("*", []):
                try:
                    handler(data)
                except Exception as e:
                    logger.error(f"Wildcard handler error: {e}")
        except Exception as e:
            logger.error(f"Message processing error: {e}")
            self._error_count += 1

    # ── Start / Stop ──────────────────────────────────────
    def start(self, daemon: bool = True):
        if self._running:
            return
        if not self._consumer:
            self.connect()
        self._running = True
        self._thread = threading.Thread(target=self._consume_loop, daemon=daemon)
        self._thread.start()
        logger.info("Consumer thread started")

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=5.0)
        if self._consumer:
            self._consumer.close()
        logger.info(f"Consumer stopped — processed: {self._message_count}, errors: {self._error_count}")

    @property
    def stats(self) -> Dict[str, Any]:
        return {
            "messages_processed": self._message_count,
            "errors":             self._error_count,
            "running":            self._running,
            "registered_topics":  list(self._handlers.keys()),
        }

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.stop()