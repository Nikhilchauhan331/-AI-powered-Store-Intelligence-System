"""
Kafka event producer with retry, gzip compression, and error handling.
"""
import json
import logging
import time
from typing import Optional, Dict, Any, List
from kafka import KafkaProducer as _KafkaProducer
from kafka.errors import KafkaError, NoBrokersAvailable
from .event_schema import BaseEvent

logger = logging.getLogger(__name__)


class EventProducer:
    """Kafka producer for Store Intelligence events."""

    def __init__(
        self,
        bootstrap_servers: str = "localhost:9092",
        topic_prefix: str = "store-intelligence",
        max_retries: int = 3,
        retry_delay: float = 1.0,
        compression: str = "gzip",
    ):
        self.bootstrap_servers = bootstrap_servers
        self.topic_prefix      = topic_prefix
        self.max_retries       = max_retries
        self.retry_delay       = retry_delay
        self._producer: Optional[_KafkaProducer] = None
        self._compression   = compression
        self._message_count = 0
        self._error_count   = 0

    # ── Connection ────────────────────────────────────────
    def connect(self) -> bool:
        for attempt in range(self.max_retries):
            try:
                self._producer = _KafkaProducer(
                    bootstrap_servers=self.bootstrap_servers,
                    value_serializer=lambda v: json.dumps(v, default=str).encode("utf-8"),
                    key_serializer=lambda k: k.encode("utf-8") if k else None,
                    compression_type=self._compression,
                    acks="all",
                    retries=3,
                    max_in_flight_requests_per_connection=1,
                    linger_ms=10,
                    batch_size=16384,
                )
                logger.info(f"Kafka producer connected to {self.bootstrap_servers}")
                return True
            except NoBrokersAvailable:
                logger.warning(f"No brokers (attempt {attempt + 1}/{self.max_retries})")
                time.sleep(self.retry_delay * (attempt + 1))
            except Exception as e:
                logger.error(f"Producer connect error: {e}")
                time.sleep(self.retry_delay)
        logger.error("Could not connect Kafka producer after all retries")
        return False

    # ── Topic Routing ─────────────────────────────────────
    def _get_topic(self, event_type: str) -> str:
        topic_map = {
            "person_detected":    "detections",
            "person_tracked":     "tracking",
            "person_entered":     "entry-exit",
            "person_exited":      "entry-exit",
            "zone_updated":       "zones",
            "anomaly_detected":   "anomalies",
            "analytics_snapshot": "analytics",
            "system_health":      "system",
        }
        suffix = topic_map.get(event_type, "general")
        return f"{self.topic_prefix}.{suffix}"

    # ── Send ──────────────────────────────────────────────
    def send_event(
        self,
        event: BaseEvent,
        key: Optional[str] = None,
        topic_override: Optional[str] = None,
    ) -> bool:
        if not self._producer and not self.connect():
            return False

        topic      = topic_override or self._get_topic(event.event_type.value)
        event_data = event.model_dump()
        msg_key    = key or event_data.get("camera_id", "default")

        try:
            future = self._producer.send(topic, value=event_data, key=msg_key)
            future.add_callback(self._on_success)
            future.add_errback(self._on_error)
            self._message_count += 1
            return True
        except KafkaError as e:
            logger.error(f"Send to {topic} failed: {e}")
            self._error_count += 1
            return False

    def send_batch(self, events: List[BaseEvent], flush: bool = True) -> int:
        sent = sum(1 for e in events if self.send_event(e))
        if flush:
            self.flush()
        return sent

    def flush(self, timeout: float = 5.0):
        if self._producer:
            self._producer.flush(timeout=timeout)

    def close(self):
        if self._producer:
            self.flush()
            self._producer.close()
            logger.info(f"Producer closed — sent: {self._message_count}, errors: {self._error_count}")

    # ── Callbacks ─────────────────────────────────────────
    def _on_success(self, metadata):
        logger.debug(f"Delivered: {metadata.topic}[{metadata.partition}]@{metadata.offset}")

    def _on_error(self, exc):
        logger.error(f"Delivery failed: {exc}")
        self._error_count += 1

    @property
    def stats(self) -> Dict[str, Any]:
        return {
            "messages_sent": self._message_count,
            "errors":        self._error_count,
            "connected":     self._producer is not None,
        }

    # ── Pipeline convenience methods (accept plain dicts) ─────────
    def _send_dict(self, topic_suffix: str, data: dict, key: str = None) -> bool:
        """Publish a plain dict to a named topic suffix (lazy-connect)."""
        if not self._producer and not self.connect():
            return False
        topic = f"{self.topic_prefix}.{topic_suffix}"
        msg_key = key or data.get("camera_id", "default")
        try:
            future = self._producer.send(topic, value=data, key=msg_key)
            future.add_callback(self._on_success)
            future.add_errback(self._on_error)
            self._message_count += 1
            return True
        except Exception as e:
            logger.error(f"Send to {topic} failed: {e}")
            self._error_count += 1
            return False

    def send_detection(self, data: dict, key: str = None) -> bool:
        return self._send_dict("detections", data, key)

    def send_anomaly(self, data: dict, key: str = None) -> bool:
        return self._send_dict("anomalies", data, key)

    def send_analytics(self, data: dict, key: str = None) -> bool:
        return self._send_dict("analytics", data, key)

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.close()


# Alias for pipeline.py backward compatibility
StoreEventProducer = EventProducer