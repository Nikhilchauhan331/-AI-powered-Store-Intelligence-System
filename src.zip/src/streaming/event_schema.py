"""
Pydantic event models for the Store Intelligence System.
Typed events for detection, tracking, analytics, and anomalies.
"""
from enum import Enum
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
import uuid
import json


class EventType(str, Enum):
    PERSON_DETECTED    = "person_detected"
    PERSON_TRACKED     = "person_tracked"
    PERSON_ENTERED     = "person_entered"
    PERSON_EXITED      = "person_exited"
    ZONE_UPDATED       = "zone_updated"
    ANOMALY_DETECTED   = "anomaly_detected"
    ANALYTICS_SNAPSHOT = "analytics_snapshot"
    SYSTEM_HEALTH      = "system_health"


class AnomalyType(str, Enum):
    LOITERING            = "loitering"
    OVERCROWDING         = "overcrowding"
    SPEED_ANOMALY        = "speed_anomaly"
    OFF_HOURS            = "off_hours_activity"
    OFF_HOURS_ACTIVITY   = "off_hours_activity"   # alias
    ZONE_DWELL           = "zone_dwell_alert"


class SeverityLevel(str, Enum):
    LOW      = "low"
    MEDIUM   = "medium"
    HIGH     = "high"
    CRITICAL = "critical"


class BoundingBox(BaseModel):
    """
    Bounding box supporting two construction formats:
      xyxy:  BoundingBox(x1=0, y1=0, x2=100, y2=200)
      xywh:  BoundingBox(x=0,  y=0,  w=100,  h=200)   ← pipeline uses this
    """
    x1: float = 0.0
    y1: float = 0.0
    x2: float = 0.0
    y2: float = 0.0

    def model_post_init(self, __context):
        pass  # x1..y2 set by validator below

    @classmethod
    def model_validate(cls, obj, *args, **kwargs):
        if isinstance(obj, dict) and "x" in obj and "x1" not in obj:
            x, y, w, h = obj["x"], obj["y"], obj["w"], obj["h"]
            obj = {"x1": x, "y1": y, "x2": x + w, "y2": y + h}
        return super().model_validate(obj, *args, **kwargs)

    def __init__(self, **data):
        # Accept x/y/w/h kwargs and convert to x1/y1/x2/y2
        if "x" in data and "x1" not in data:
            data["x1"] = data.pop("x")
            data["y1"] = data.pop("y")
            w = data.pop("w", 0)
            h = data.pop("h", 0)
            data["x2"] = data["x1"] + w
            data["y2"] = data["y1"] + h
        super().__init__(**data)

    @property
    def center(self) -> tuple:
        return ((self.x1 + self.x2) / 2, (self.y1 + self.y2) / 2)

    @property
    def area(self) -> float:
        return (self.x2 - self.x1) * (self.y2 - self.y1)

    def to_list(self) -> list:
        return [self.x1, self.y1, self.x2, self.y2]


class BaseEvent(BaseModel):
    event_id: str       = Field(default_factory=lambda: str(uuid.uuid4()))
    event_type: EventType
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    camera_id: str      = "cam_01"
    store_id: str       = "store_01"
    frame_id: int       = 0
    frame_number: int   = 0   # alias for frame_id used by pipeline
    metadata: Dict[str, Any] = Field(default_factory=dict)


class DetectionEvent(BaseEvent):
    event_type: EventType  = EventType.PERSON_DETECTED
    bbox: BoundingBox      = Field(default_factory=lambda: BoundingBox())
    confidence: float      = 0.0
    zone_id: Optional[str] = None
    zone_name: Optional[str] = None
    class_name: str        = "person"
    track_id: int          = 0
    velocity_x: float      = 0.0
    velocity_y: float      = 0.0
    speed: float           = 0.0


class TrackingEvent(BaseEvent):
    event_type: EventType = EventType.PERSON_TRACKED
    track_id: int
    bbox: BoundingBox
    confidence: float
    zone_id: Optional[str]      = None
    velocity: Optional[float]   = None
    dwell_time: Optional[float] = None
    zones_visited: List[str]    = Field(default_factory=list)


class EntryExitEvent(BaseEvent):
    track_id: int
    zone_id: str
    direction: str                        # "entry" or "exit"
    total_dwell_time: Optional[float] = None


class ZoneUpdateEvent(BaseEvent):
    event_type: EventType = EventType.ZONE_UPDATED
    zone_id: str
    current_count: int
    max_capacity: int
    occupancy_pct: float


class AnomalyEvent(BaseEvent):
    event_type: EventType = EventType.ANOMALY_DETECTED
    anomaly_type: AnomalyType
    severity: SeverityLevel
    zone_id: Optional[str]  = None
    track_id: Optional[int] = None
    description: str        = ""
    details: Dict[str, Any] = Field(default_factory=dict)


class AnalyticsSnapshot(BaseEvent):
    event_type: EventType        = EventType.ANALYTICS_SNAPSHOT
    total_people: int            = 0
    zone_counts: Dict[str, int]  = Field(default_factory=dict)
    entry_count: int             = 0
    exit_count: int              = 0
    active_anomalies: int        = 0
    fps: float                   = 0.0


# Aliases for backward compatibility
Severity = SeverityLevel
AnalyticsEvent = AnalyticsSnapshot


class FullAnalyticsEvent(BaseModel):
    """Extended analytics event used by AnalyticsEngine.get_snapshot()."""
    camera_id: str
    store_id: str
    window_start: datetime
    window_end: datetime
    total_count: int             = 0
    zone_counts: Dict[str, int]  = Field(default_factory=dict)
    avg_dwell_time: float        = 0.0
    throughput_per_minute: float = 0.0
    heatmap_data: Dict[str, float] = Field(default_factory=dict)
    active_track_ids: List[int]  = Field(default_factory=list)


class StoreEvent(BaseModel):
    """Wrapper that can hold any event type for Kafka serialization."""
    event: BaseEvent

    def to_json(self) -> str:
        return json.dumps(self.event.model_dump(), default=str)

    @classmethod
    def from_json(cls, data: str) -> "StoreEvent":
        parsed = json.loads(data)
        event_type = parsed.get("event_type", "")
        type_map = {
            EventType.PERSON_DETECTED:    DetectionEvent,
            EventType.PERSON_TRACKED:     TrackingEvent,
            EventType.PERSON_ENTERED:     EntryExitEvent,
            EventType.PERSON_EXITED:      EntryExitEvent,
            EventType.ZONE_UPDATED:       ZoneUpdateEvent,
            EventType.ANOMALY_DETECTED:   AnomalyEvent,
            EventType.ANALYTICS_SNAPSHOT: AnalyticsSnapshot,
        }
        try:
            evt_cls = type_map.get(EventType(event_type), BaseEvent)
        except ValueError:
            evt_cls = BaseEvent
        return cls(event=evt_cls(**parsed))