"""FastAPI application — REST API + WebSocket for Store Intelligence System."""

import logging
import time
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from src.api.routes import health, detections, analytics, anomalies, zones, events

logger = logging.getLogger(__name__)

_start_time = time.time()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: wire optional services; yield; Shutdown: clean up."""

    analytics_engine = None
    cache_manager    = None
    pipeline         = None

    # ── Analytics engine (always try — it's pure Python) ──────────
    try:
        from src.analytics.analytics_engine import AnalyticsEngine
        analytics_engine = AnalyticsEngine()
        logger.info("AnalyticsEngine initialized")
    except Exception as exc:
        logger.warning(f"AnalyticsEngine unavailable: {exc}")

    # ── Redis / Cache ──────────────────────────────────────────────
    try:
        from src.storage.redis_client import CacheManager
        cache_manager = CacheManager()
        logger.info("CacheManager initialized")
    except Exception as exc:
        logger.warning(f"CacheManager unavailable: {exc}")

    # ── Pipeline (optional — needs video source + model) ──────────
    try:
        from src.pipeline.pipeline import StorePipeline
        pipeline = StorePipeline()
        logger.info("StorePipeline initialized")
    except Exception as exc:
        logger.warning(f"StorePipeline unavailable (API runs without video): {exc}")

    # ── Inject dependencies into route handlers ────────────────────
    analytics.set_dependencies(analytics_engine, cache_manager)

    app.state.analytics_engine = analytics_engine
    app.state.cache_manager    = cache_manager
    app.state.pipeline         = pipeline

    yield  # ← API serves requests here

    # ── Shutdown ───────────────────────────────────────────────────
    if pipeline and hasattr(pipeline, "stop"):
        try:
            pipeline.stop()
        except Exception:
            pass
    logger.info("Store Intelligence API shut down cleanly")


# ── App ────────────────────────────────────────────────────────────
app = FastAPI(
    title="Store Intelligence System",
    description="AI-powered store analytics from CCTV footage",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ────────────────────────────────────────────────────────
app.include_router(health.router)                                   # /health
app.include_router(analytics.router)                                # /api/v1/analytics/...  (prefix built-in)
app.include_router(detections.router, prefix="/api/v1")             # /api/v1/detections/...
app.include_router(anomalies.router,  prefix="/api/v1")             # /api/v1/anomalies/...
app.include_router(zones.router,      prefix="/api/v1")             # /api/v1/zones/...
app.include_router(events.router)                                   # /api/v1/events/..., /api/v1/ws/events (prefix built-in)


# ── Top-level convenience routes ───────────────────────────────────
@app.get("/", include_in_schema=False)
async def root():
    return {
        "service": "Store Intelligence System",
        "version": "1.0.0",
        "docs":    "/docs",
        "health":  "/health",
    }


# ── Optional: Prometheus metrics (skip if prometheus_client missing) ─
try:
    from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
    from starlette.responses import Response

    @app.get("/metrics", include_in_schema=False)
    async def prometheus_metrics():
        return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)

except ImportError:
    pass
