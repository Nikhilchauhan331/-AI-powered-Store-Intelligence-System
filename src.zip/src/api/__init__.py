"""API module — FastAPI REST endpoints and WebSocket server."""
from .main import app
__all__ = ["app"]