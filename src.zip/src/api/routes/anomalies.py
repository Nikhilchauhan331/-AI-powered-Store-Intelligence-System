from fastapi import APIRouter, Request, Query
from typing import Optional
from src.api.models.schemas import AnomalyListResponse, AnomalyResponse

router = APIRouter()


@router.get("/anomalies", response_model=AnomalyListResponse)
async def get_anomalies(request: Request, limit: int = Query(50, ge=1, le=500),
                        severity: Optional[str] = None, anomaly_type: Optional[str] = None):
    pipeline = request.app.state.pipeline
    if not pipeline:
        return AnomalyListResponse(total=0, anomalies=[], counts_by_type={})
    anomalies = pipeline.anomaly_detector.get_recent_anomalies(limit=limit)
    if severity:
        anomalies = [a for a in anomalies if a.get("severity") == severity]
    if anomaly_type:
        anomalies = [a for a in anomalies if a.get("type") == anomaly_type]
    return AnomalyListResponse(
        total=len(anomalies),
        anomalies=[AnomalyResponse(
            anomaly_type=a["type"], severity=a["severity"], description=a["description"],
            affected_tracks=a.get("track_ids", []), zone_id=a.get("zone_id"),
            threshold=a.get("threshold", 0), actual_value=a.get("actual_value", 0),
            camera_id=a.get("camera_id", ""), timestamp=a.get("timestamp", ""),
        ) for a in anomalies],
        counts_by_type=pipeline.anomaly_detector.get_anomaly_counts(),
    )


@router.get("/anomalies/counts")
async def get_anomaly_counts(request: Request):
    pipeline = request.app.state.pipeline
    return {"counts": pipeline.anomaly_detector.get_anomaly_counts() if pipeline else {}}