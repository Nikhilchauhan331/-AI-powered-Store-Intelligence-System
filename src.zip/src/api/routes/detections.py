from fastapi import APIRouter, Request
from datetime import datetime, timezone
from src.api.models.schemas import DetectionResponse, ActiveTracksResponse

router = APIRouter()


@router.get("/detections/active", response_model=ActiveTracksResponse)
async def get_active_detections(request: Request):
    pipeline = request.app.state.pipeline
    tracks = pipeline.tracker.get_active_tracks() if pipeline else []
    return ActiveTracksResponse(
        camera_id=pipeline.camera_id if pipeline else "unknown",
        timestamp=datetime.now(timezone.utc).isoformat(),
        active_count=len(tracks),
        tracks=[DetectionResponse(
            track_id=t.track_id, bbox=list(t.bbox), confidence=t.confidence,
            class_name=t.class_name, center=list(t.center), zone_id=t.zone_id,
            dwell_time_seconds=round(t.age_seconds, 2), speed=round(t.speed, 2),
        ) for t in tracks],
    )


@router.get("/detections/track/{track_id}")
async def get_track_detail(track_id: int, request: Request):
    pipeline = request.app.state.pipeline
    track = pipeline.tracker.get_track(track_id) if pipeline else None
    return track.to_dict() if track else {"error": f"Track {track_id} not found"}


@router.get("/detections/count")
async def get_detection_count(request: Request):
    pipeline = request.app.state.pipeline
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "active_count": pipeline.tracker.get_track_count() if pipeline else 0,
        "total_unique": pipeline.tracker.total_unique_tracks if pipeline else 0,
    }


@router.get("/detections/stats")
async def get_detection_stats(request: Request):
    pipeline = request.app.state.pipeline
    return pipeline.tracker.get_stats() if pipeline else {"error": "Pipeline not running"}