import asyncio
import structlog
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from datetime import datetime, timezone
from typing import Set

logger = structlog.get_logger()
router = APIRouter()
connected_clients: Set[WebSocket] = set()


@router.websocket("/ws/events")
async def websocket_events(websocket: WebSocket):
    await websocket.accept()
    connected_clients.add(websocket)
    try:
        while True:
            pipeline = getattr(websocket.app.state, "pipeline", None)
            if not pipeline:
                await asyncio.sleep(1)
                continue
            tracks = pipeline.tracker.get_active_tracks()
            anomalies = pipeline.anomaly_detector.get_recent_anomalies(limit=5)
            payload = {
                "type": "REALTIME_UPDATE",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "data": {
                    "active_count": len(tracks),
                    "total_footfall": pipeline.analytics.total_footfall,
                    "fps": round(pipeline.fps, 1),
                    "tracks": [t.to_dict() for t in tracks[:50]],
                    "zone_counts": pipeline.analytics.get_zone_counts(),
                    "recent_anomalies": anomalies[-3:],
                },
            }
            await websocket.send_json(payload)
            await asyncio.sleep(1)
    except WebSocketDisconnect:
        connected_clients.discard(websocket)
    except Exception:
        connected_clients.discard(websocket)