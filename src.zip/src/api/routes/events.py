"""Event listing + WebSocket real-time streaming."""
import asyncio
import json
import logging
from typing import Optional, List
from datetime import datetime
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1", tags=["Events"])

# ── Shared ring buffer ────────────────────────────────────
_event_buffer: List[dict]    = []
_max_buffer                  = 1000
_ws_clients: List[WebSocket] = []


def push_event(event: dict):
    """Called by the pipeline to add events to the buffer."""
    global _event_buffer
    _event_buffer.append(event)
    if len(_event_buffer) > _max_buffer:
        _event_buffer = _event_buffer[-_max_buffer:]


async def broadcast_event(event: dict):
    """Push event to every open WebSocket client."""
    dead = []
    for ws in _ws_clients:
        try:
            await ws.send_json(event)
        except Exception:
            dead.append(ws)
    for ws in dead:
        _ws_clients.remove(ws)


# ── REST ──────────────────────────────────────────────────
@router.get("/events/recent")
async def get_recent_events(
    limit: int               = Query(50, ge=1, le=500),
    camera_id: Optional[str] = None,
    event_type: Optional[str] = None,
):
    events = list(reversed(_event_buffer[-limit:]))
    if camera_id:
        events = [e for e in events if e.get("camera_id") == camera_id]
    if event_type:
        events = [e for e in events if e.get("event_type") == event_type]
    return events


@router.get("/events/count")
async def get_event_count():
    return {"total_events": len(_event_buffer)}


# ── WebSocket ─────────────────────────────────────────────
@router.websocket("/ws/events")
async def websocket_events(websocket: WebSocket):
    await websocket.accept()
    _ws_clients.append(websocket)
    logger.info(f"WS client connected (total={len(_ws_clients)})")
    try:
        while True:
            try:
                data = await asyncio.wait_for(websocket.receive_text(), timeout=30.0)
                logger.debug(f"WS received: {data}")
            except asyncio.TimeoutError:
                # heartbeat
                await websocket.send_json(
                    {"type": "heartbeat", "timestamp": datetime.utcnow().isoformat()}
                )
    except WebSocketDisconnect:
        logger.info("WS client disconnected")
    except Exception as e:
        logger.error(f"WS error: {e}")
    finally:
        if websocket in _ws_clients:
            _ws_clients.remove(websocket)