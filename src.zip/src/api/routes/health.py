"""Health check endpoint."""
import time
from fastapi import APIRouter
from ..models import HealthResponse

router = APIRouter(tags=["Health"])

_start_time = time.time()


@router.get("/health", response_model=HealthResponse)
async def health_check():
    return HealthResponse(
        status="healthy",
        version="1.0.0",
        uptime_seconds=round(time.time() - _start_time, 2),
        services={
            "api":       "running",
            "detection": "ready",
            "tracking":  "ready",
            "analytics": "ready",
        },
    )


@router.get("/", include_in_schema=False)
async def root():
    return {
        "service": "Store Intelligence System",
        "version": "1.0.0",
        "docs":    "/docs",
        "health":  "/health",
    }
