"""API route modules."""
from .health    import router as health_router
from .analytics import router as analytics_router
from .events    import router as events_router

__all__ = ["health_router", "analytics_router", "events_router"]