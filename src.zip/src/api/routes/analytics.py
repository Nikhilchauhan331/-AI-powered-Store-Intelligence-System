"""Analytics endpoints — counts, zones, heatmaps, tracks, anomalies, stats."""
from fastapi import APIRouter, Query, HTTPException
from typing import Optional
from datetime import datetime
from ..models import (
    CountResponse, ZoneOccupancyResponse, ZoneDetailResponse,
    HeatmapResponse, StatisticsResponse,
)

router = APIRouter(prefix="/api/v1", tags=["Analytics"])

# Injected at startup by main.py
_analytics_engine = None
_cache_manager    = None


def set_dependencies(analytics_engine, cache_manager=None):
    global _analytics_engine, _cache_manager
    _analytics_engine = analytics_engine
    _cache_manager    = cache_manager


# ── People Count ──────────────────────────────────────────
@router.get("/analytics/count/current", response_model=CountResponse)
async def get_current_count(camera_id: str = "cam_01"):
    # Prefer cache snapshot from pipeline if available
    if _cache_manager:
        snap = _cache_manager.get_analytics(camera_id)
        if snap and isinstance(snap, dict) and snap.get("total_count") is not None:
            return CountResponse(count=int(snap.get("total_count", 0)), camera_id=camera_id)
    count = _analytics_engine.get_current_count(camera_id) if _analytics_engine else 0
    return CountResponse(count=count, camera_id=camera_id)


@router.get("/analytics/count/history")
async def get_count_history(
    minutes: int   = Query(30, ge=1, le=1440),
    camera_id: str = "cam_01",
):
    if _analytics_engine and hasattr(_analytics_engine, "get_count_history"):
        return _analytics_engine.get_count_history(camera_id, minutes)
    return []


# ── Zone Occupancy ────────────────────────────────────────
@router.get("/analytics/zones/occupancy")
async def get_zone_occupancy():
    # Prefer cached analytics snapshot if available
    if _cache_manager:
        snap = _cache_manager.get_analytics("cam_01")
        if snap and isinstance(snap, dict):
            zones = snap.get("zone_counts", {})
            return {"zones": zones, "total_people": sum(zones.values()),
                    "timestamp": datetime.utcnow().isoformat()}
    zones = _analytics_engine.get_zone_occupancy() if _analytics_engine else {}
    return {"zones": zones, "total_people": sum(zones.values()),
            "timestamp": datetime.utcnow().isoformat()}


@router.get("/analytics/zones/heatmap")
async def get_heatmap():
    if _analytics_engine:
        hm = _analytics_engine.get_heatmap()
        return HeatmapResponse(data=hm.tolist(),
                               width=hm.shape[1] if hm.ndim > 1 else 640,
                               height=hm.shape[0])
    return HeatmapResponse()


@router.get("/analytics/zones/{zone_id}")
async def get_zone_detail(zone_id: str):
    if _analytics_engine:
        occ = _analytics_engine.get_zone_occupancy()
        if zone_id in occ:
            return ZoneDetailResponse(zone_id=zone_id, current_count=occ[zone_id])
    raise HTTPException(status_code=404, detail=f"Zone '{zone_id}' not found")


# ── Tracks ────────────────────────────────────────────────
@router.get("/tracks/active")
async def get_active_tracks():
    if _analytics_engine and hasattr(_analytics_engine, "get_active_tracks"):
        return _analytics_engine.get_active_tracks()
    return []


@router.get("/tracks/{track_id}")
async def get_track(track_id: int):
    if _analytics_engine and hasattr(_analytics_engine, "get_track"):
        track = _analytics_engine.get_track(track_id)
        if track:
            return track
    raise HTTPException(status_code=404, detail=f"Track {track_id} not found")


# ── Anomalies ────────────────────────────────────────────
@router.get("/anomalies/active")
async def get_active_anomalies(type: Optional[str] = None):
    # Prefer stored anomalies in cache if pipeline is pushing them
    if _cache_manager and hasattr(_cache_manager, "get_active_anomalies"):
        anomalies = _cache_manager.get_active_anomalies() or []
        if type:
            anomalies = [a for a in anomalies if a.get("anomaly_type") == type]
        return anomalies
    if _analytics_engine and hasattr(_analytics_engine, "get_active_anomalies"):
        anomalies = _analytics_engine.get_active_anomalies()
        if type:
            anomalies = [a for a in anomalies if a.get("anomaly_type") == type]
        return anomalies
    return []


@router.get("/anomalies/history")
async def get_anomaly_history(minutes: int = Query(60, ge=1, le=1440)):
    if _analytics_engine and hasattr(_analytics_engine, "get_anomaly_history"):
        return _analytics_engine.get_anomaly_history(minutes)
    return []


# ── Statistics ────────────────────────────────────────────
@router.get("/analytics/statistics", response_model=StatisticsResponse)
async def get_statistics():
    if _analytics_engine:
        return StatisticsResponse(**_analytics_engine.get_statistics())
    return StatisticsResponse()
