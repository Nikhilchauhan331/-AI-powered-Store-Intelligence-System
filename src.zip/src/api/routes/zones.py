import json
from fastapi import APIRouter, Request
from src.api.models.schemas import ZoneConfig

router = APIRouter()


@router.get("/zones")
async def get_zones(request: Request):
    pipeline = request.app.state.pipeline
    return {"zones": pipeline.zones if pipeline else {}}


@router.post("/zones")
async def create_zone(zone: ZoneConfig, request: Request):
    pipeline = request.app.state.pipeline
    if not pipeline:
        return {"error": "Pipeline not running"}
    pipeline.zones[zone.zone_id] = {
        "name": zone.name, "polygon": zone.polygon,
        "color": zone.color, "max_capacity": zone.max_capacity,
    }
    try:
        with open("zones/default_zones.json", "w") as f:
            json.dump(pipeline.zones, f, indent=2)
    except Exception:
        pass
    return {"status": "created", "zone": zone.dict()}


@router.delete("/zones/{zone_id}")
async def delete_zone(zone_id: str, request: Request):
    pipeline = request.app.state.pipeline
    if not pipeline:
        return {"error": "Pipeline not running"}
    if zone_id in pipeline.zones:
        del pipeline.zones[zone_id]
        return {"status": "deleted", "zone_id": zone_id}
    return {"error": f"Zone {zone_id} not found"}