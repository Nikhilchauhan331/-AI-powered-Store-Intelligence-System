"""Pydantic models for API request/response schemas."""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any


class HealthResponse(BaseModel):
    status: str = "healthy"
    version: str = "1.0.0"
    uptime_seconds: float
    components: Dict[str, str]


class DetectionResponse(BaseModel):
    track_id: int
    bbox: List[float]
    confidence: float
    class_name: str
    center: List[float]
    zone_id: Optional[str] = None
    dwell_time_seconds: float
    speed: float


class ActiveTracksResponse(BaseModel):
    camera_id: str
    timestamp: str
    active_count: int
    tracks: List[DetectionResponse]


class AnalyticsResponse(BaseModel):
    timestamp: str
    active_count: int
    total_footfall: int
    zone_metrics: Dict[str, Any]
    avg_dwell_time: float


class FootfallResponse(BaseModel):
    total: int
    hourly: Dict[str, int]
    time_series: List[dict]


class ZoneConfig(BaseModel):
    zone_id: str
    name: str
    polygon: List[List[int]] = Field(..., description="List of [x, y] coordinates")
    color: List[int] = Field(default=[0, 255, 255])
    max_capacity: int = Field(default=20)


class AnomalyResponse(BaseModel):
    event_id: Optional[str] = None
    anomaly_type: str
    severity: str
    description: str
    affected_tracks: List[int]
    zone_id: Optional[str] = None
    threshold: float
    actual_value: float
    camera_id: str
    timestamp: str


class AnomalyListResponse(BaseModel):
    total: int
    anomalies: List[AnomalyResponse]
    counts_by_type: Dict[str, int]


class HeatmapResponse(BaseModel):
    image_base64: str
    hotspots: List[dict]
    total_data_points: int