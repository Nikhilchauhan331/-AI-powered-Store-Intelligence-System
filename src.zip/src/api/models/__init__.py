"""
API models package — exports all schemas for all routes.

Priority: models from models.py (new) take precedence for shared names
(HealthResponse, HeatmapResponse, AnomalyResponse) so analytics/health
routes work correctly. schemas.py models still importable via
`from src.api.models.schemas import ...` for routes that need them.
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime

# ── New models (from models.py flat file) ─────────────────────────


class HealthResponse(BaseModel):
    status: str               = "healthy"
    version: str              = "1.0.0"
    uptime_seconds: float     = 0.0
    services: Dict[str, str]  = Field(default_factory=dict)


class CountResponse(BaseModel):
    count: int       = 0
    camera_id: str   = "cam_01"
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ZoneOccupancyResponse(BaseModel):
    zones: Dict[str, int] = Field(default_factory=dict)
    total_people: int     = 0
    timestamp: datetime   = Field(default_factory=datetime.utcnow)


class ZoneDetailResponse(BaseModel):
    zone_id: str
    current_count: int    = 0
    max_capacity: int     = 50
    occupancy_pct: float  = 0.0
    avg_dwell_time: float = 0.0


class HeatmapResponse(BaseModel):
    data: List[List[float]] = Field(default_factory=list)
    width: int              = 640
    height: int             = 480
    timestamp: datetime     = Field(default_factory=datetime.utcnow)


class TrackResponse(BaseModel):
    track_id: int
    bbox: List[int]
    confidence: float
    zone_id: Optional[str] = None
    dwell_time: float      = 0.0
    velocity: float        = 0.0
    age: int               = 0


class AnomalyResponse(BaseModel):
    anomaly_id: str
    anomaly_type: str
    severity: str
    zone_id: Optional[str]  = None
    track_id: Optional[int] = None
    description: str        = ""
    timestamp: datetime     = Field(default_factory=datetime.utcnow)
    resolved: bool          = False


class EventResponse(BaseModel):
    event_id: str
    event_type: str
    timestamp: datetime
    camera_id: str           = "cam_01"
    data: Dict[str, Any]     = Field(default_factory=dict)


class StatisticsResponse(BaseModel):
    total_visitors: int    = 0
    current_occupancy: int = 0
    active_zones: int      = 0
    active_anomalies: int  = 0
    avg_dwell_time: float  = 0.0
    peak_occupancy: int    = 0
    fps: float             = 0.0
    uptime_seconds: float  = 0.0


class ErrorResponse(BaseModel):
    error: str
    detail: Optional[str] = None
    status_code: int       = 500


# ── schemas.py models (imported for routes that use them) ──────────
from .schemas import (
    DetectionResponse,
    ActiveTracksResponse,
    AnalyticsResponse,
    FootfallResponse,
    ZoneConfig,
    AnomalyListResponse,
)

__all__ = [
    # New models
    "HealthResponse",
    "CountResponse",
    "ZoneOccupancyResponse",
    "ZoneDetailResponse",
    "HeatmapResponse",
    "TrackResponse",
    "AnomalyResponse",
    "EventResponse",
    "StatisticsResponse",
    "ErrorResponse",
    # schemas.py models
    "DetectionResponse",
    "ActiveTracksResponse",
    "AnalyticsResponse",
    "FootfallResponse",
    "ZoneConfig",
    "AnomalyListResponse",
]
