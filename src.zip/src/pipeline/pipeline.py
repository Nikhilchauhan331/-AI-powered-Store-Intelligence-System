"""
Main pipeline orchestrator.
Ties together:
  StoreDetector    → YOLOv8 inference + zone mapping
  StoreTracker     → DeepSORT tracking + dwell time
  StoreEventProducer → Kafka publishing
  AnalyticsEngine  → rolling footfall / heatmap
  AnomalyDetector  → 5-strategy anomaly detection
  RedisClient      → live cache for dashboard/API
"""
import cv2
import os
import sys
import signal
import time
import yaml
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional
from loguru import logger
from dotenv import load_dotenv

load_dotenv()


class StorePipeline:

    def __init__(self, config_path: str = "config/config.yaml"):
        with open(config_path) as f:
            self.config = yaml.safe_load(f)

        self.camera_id    = os.getenv("CAMERA_ID",    "CAM_001")
        self.store_id     = os.getenv("STORE_ID",     "STORE_001")
        self.video_source = os.getenv("VIDEO_SOURCE", "data/sample.mp4")

        # Lazy imports (avoids circular deps during testing)
        from src.detection.detector    import StoreDetector, Detection
        from src.tracking.tracker      import StoreTracker
        from src.streaming.kafka_producer  import StoreEventProducer
        from src.analytics.analytics_engine import AnalyticsEngine
        from src.anomaly.anomaly_detector   import AnomalyDetector
        from src.storage.redis_client   import RedisClient
        from src.streaming.event_schema import DetectionEvent, BoundingBox

        self.DetectionCls  = Detection
        self.DetectionEvent = DetectionEvent
        self.BoundingBox    = BoundingBox

        self.detector  = StoreDetector(config_path)
        self.tracker   = StoreTracker(config_path)
        self.producer  = StoreEventProducer()
        self.analytics = AnalyticsEngine(config_path)
        self.anomaly   = AnomalyDetector(config_path)
        self.redis     = RedisClient()
        # Try to connect Redis so analytics/anomalies are available to API
        try:
            if hasattr(self.redis, "connect"):
                if self.redis.connect():
                    logger.info("Redis client connected from pipeline")
                else:
                    logger.warning("Redis client not connected from pipeline — continuing without cache")
        except Exception as exc:
            logger.warning(f"Redis connection attempt failed: {exc}")

        self._running     = False
        self._frame_count = 0
        self._start_time  = None

        analytics_cfg = self.config.get("analytics", {})
        self._analytics_interval = analytics_cfg.get("update_interval_seconds", 5)

        signal.signal(signal.SIGINT, self._shutdown)
        # SIGTERM does not exist on Windows — guard it
        if hasattr(signal, "SIGTERM"):
            signal.signal(signal.SIGTERM, self._shutdown)

    def _resolve_video_source(self) -> str:
        """Resolve the configured video source, allowing common filename variants."""
        source = str(self.video_source)
        source_path = Path(source)
        if source_path.exists():
            return source

        data_dir = Path("data")
        if source_path.is_absolute():
            return source

        normalized_target = "".join(ch.lower() for ch in source_path.name if ch.isalnum())
        candidates = []
        if data_dir.exists():
            for item in data_dir.iterdir():
                if not item.is_file():
                    continue
                normalized_name = "".join(ch.lower() for ch in item.name if ch.isalnum())
                if normalized_name == normalized_target:
                    candidates.append(item)

        if candidates:
            return str(candidates[0])

        return source

    def _shutdown(self, signum, frame):
        logger.info("Shutdown signal — stopping pipeline...")
        self._running = False

    # ── Main loop ──────────────────────────────────────────────────
    def run(self):
        # Try to open source — "0" means webcam
        resolved_source = self._resolve_video_source()
        source = 0 if str(resolved_source) == "0" else resolved_source
        cap = cv2.VideoCapture(source)

        if not cap.isOpened():
            logger.error(
                f"Cannot open video source: {self.video_source} "
                f"(resolved to {resolved_source})"
            )
            if Path("data").exists():
                available = [p.name for p in Path("data").iterdir() if p.is_file()]
                logger.error(f"Available files in data/: {available}")
            sys.exit(1)

        fps   = cap.get(cv2.CAP_PROP_FPS) or 25.0
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        logger.info(
            f"Pipeline starting | source={self.video_source} "
            f"fps={fps:.1f} total_frames={total}"
        )

        self._running    = True
        self._start_time = time.time()
        last_analytics_push = time.time()

        try:
            while self._running:
                ret, frame = cap.read()
                if not ret:
                    if total > 0:
                        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)  # loop file
                        continue
                    break

                self._frame_count += 1
                frame_h, frame_w = frame.shape[:2]
                now = datetime.now(timezone.utc)

                # 1. Detect ─────────────────────────────────────────
                raw_dets, annotated = self.detector.detect_annotated(frame)

                # 2. Track ──────────────────────────────────────────
                tracks = self.tracker.update(raw_dets, frame)

                # 3. Zone enrichment ────────────────────────────────
                for t in tracks:
                    cx, cy = t["center"]
                    zone_id, zone_name = self.detector.get_zone_for_point(
                        cx, cy, frame_w, frame_h
                    )
                    t["zone_id"]   = zone_id
                    t["zone_name"] = zone_name
                    if zone_id:
                        self.tracker.update_zone(t["track_id"], zone_id)

                # 4. Build Detection dataclass list ──────────────────
                det_objs = [
                    self.DetectionCls(
                        track_id=t["track_id"],
                        bbox=t["bbox_norm"],
                        confidence=t["confidence"],
                        zone_id=t.get("zone_id"),
                        zone_name=t.get("zone_name"),
                        frame_number=self._frame_count,
                    )
                    for t in tracks
                ]

                # 5. Publish detection events ────────────────────────
                for t in tracks:
                    bn = t["bbox_norm"]
                    event = self.DetectionEvent(
                        camera_id=self.camera_id,
                        store_id=self.store_id,
                        frame_number=self._frame_count,
                        track_id=t["track_id"],
                        bbox=self.BoundingBox(x=bn[0], y=bn[1], w=bn[2], h=bn[3]),
                        confidence=t["confidence"],
                        zone_id=t.get("zone_id"),
                        zone_name=t.get("zone_name"),
                        velocity_x=t.get("velocity_x", 0.0),
                        velocity_y=t.get("velocity_y", 0.0),
                        speed=t.get("speed", 0.0),
                    )
                    self.producer.send_detection(
                        event.model_dump(),
                        key=f"{self.camera_id}:{t['track_id']}",
                    )

                # 6. Update analytics ────────────────────────────────
                self.analytics.update(det_objs, self._frame_count, now)

                # 7. Detect anomalies ────────────────────────────────
                anomalies = self.anomaly.detect(
                    detections=tracks,
                    tracker=self.tracker,
                    detector=self.detector,
                    camera_id=self.camera_id,
                    store_id=self.store_id,
                    timestamp=now,
                )
                for a in anomalies:
                    payload = a.model_dump()
                    self.producer.send_anomaly(payload)
                    self.redis.push_anomaly(payload)

                # 8. Periodic analytics snapshot ─────────────────────
                if time.time() - last_analytics_push >= self._analytics_interval:
                    snap = self.analytics.get_snapshot(self.camera_id, self.store_id, now)
                    snap_dict = snap.model_dump()
                    self.producer.send_analytics(snap_dict)
                    self.redis.set_analytics(self.camera_id, snap_dict)
                    last_analytics_push = time.time()
                    logger.debug(
                        f"Analytics | people={snap.total_count} "
                        f"throughput={snap.throughput_per_minute:.1f}/min"
                    )

                # 9. Render & display ────────────────────────────────
                annotated = self.detector.draw_tracks(annotated, det_objs)
                self._draw_overlay(annotated, len(tracks), len(anomalies))
                cv2.imshow("Store Intelligence — press Q to quit", annotated)
                if cv2.waitKey(1) & 0xFF in (ord('q'), ord('Q')):
                    break

                # Soft FPS throttle
                self._throttle(fps)

        finally:
            cap.release()
            cv2.destroyAllWindows()
            self.producer.flush()
            self.producer.close()
            elapsed = time.time() - (self._start_time or time.time())
            logger.info(
                f"Pipeline stopped | frames={self._frame_count} "
                f"elapsed={elapsed:.1f}s "
                f"avg_fps={self._frame_count / max(elapsed, 1):.1f}"
            )

    def _throttle(self, target_fps: float):
        """Soft FPS limiter to avoid burning CPU."""
        if self._start_time and target_fps > 0:
            expected = self._frame_count / target_fps
            drift = expected - (time.time() - self._start_time)
            if 0 < drift < 0.1:
                time.sleep(drift)

    def _draw_overlay(self, frame, count: int, anomaly_count: int):
        """Semi-transparent stats overlay in top-left corner."""
        import numpy as np
        overlay = frame.copy()
        cv2.rectangle(overlay, (0, 0), (300, 90), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.45, frame, 0.55, 0, frame)
        fps_actual = self._frame_count / max(time.time() - self._start_time, 1)
        cv2.putText(frame, f"People: {count}",
                    (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 60), 2)
        cv2.putText(frame, f"Anomalies: {anomaly_count}",
                    (10, 58), cv2.FONT_HERSHEY_SIMPLEX, 0.75,
                    (0, 60, 255) if anomaly_count > 0 else (0, 255, 60), 2)
        cv2.putText(frame, f"FPS: {fps_actual:.1f}  Frame: {self._frame_count}",
                    (10, 82), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (200, 200, 200), 1)


if __name__ == "__main__":
    pipeline = StorePipeline()
    pipeline.run()
