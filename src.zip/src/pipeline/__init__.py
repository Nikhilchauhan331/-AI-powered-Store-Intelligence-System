"""Pipeline module namespace."""

from importlib import import_module

__all__ = ["StorePipeline", "Pipeline"]


def __getattr__(name):
	if name in __all__:
		module = import_module(".pipeline", __name__)
		return getattr(module, "StorePipeline")
	raise AttributeError(f"module {__name__!r} has no attribute {name!r}")