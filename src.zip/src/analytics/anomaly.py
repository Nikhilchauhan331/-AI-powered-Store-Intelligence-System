"""Anomaly detection engine — loitering, overcrowding, speed, off-hours."""

import time
import structlog
from typing import Dict, List
from datetime import datetime
from config.settings import settings

logger = structlog.get_logger()


class AnomalyDetector:
    def __init__(self):
        self.loiter_threshold = settings.loiter_threshold_seconds
        self.overcrowding_threshold = settings.overcrowding_threshold
        self.speed_threshold = settings.speed_anomaly_threshold
        self.zone_dwell_threshold = settings.zone_dwell_alert_seconds
        self._alert_cooldowns: Dict[str, float] = {}
        self._cooldown_period = 30
        self.store_open_hour = 6
        self.store_close_hour = 23
        self.anomaly_history: List[dict] = []

    def check(self, tracks, zone_counts, camera_id) -> List[dict]:
        anomalies = []
        now = time.time()

        # 1. Loitering
        for track in tracks:
            if track.age_seconds > self.loiter_threshold:
                key = f"loiter_{track.track_id}"
                if self._is_cooled_down(key, now):
                    severity = "critical" if track.age_seconds > self.loiter_threshold * 3 else \
                               "high" if track.age_seconds > self.loiter_threshold * 2 else "medium"
                    anomalies.append({
                        "type": "LOITERING", "severity": severity,
                        "description": f"Person (track {track.track_id}) stationary for {track.age_seconds:.0f}s",
                        "track_ids": [track.track_id], "zone_id": track.zone_id,
                        "threshold": self.loiter_threshold, "actual_value": track.age_seconds,
                        "camera_id": camera_id, "timestamp": datetime.utcnow().isoformat(),
                    })
                    self._alert_cooldowns[key] = now

        # 2. Overcrowding
        total_active = len(tracks)
        if total_active > self.overcrowding_threshold:
            key = "overcrowd_global"
            if self._is_cooled_down(key, now):
                anomalies.append({
                    "type": "OVERCROWDING",
                    "severity": "high" if total_active > self.overcrowding_threshold * 1.5 else "medium",
                    "description": f"Overcrowding: {total_active} people (threshold: {self.overcrowding_threshold})",
                    "track_ids": [t.track_id for t in tracks], "zone_id": None,
                    "threshold": self.overcrowding_threshold, "actual_value": total_active,
                    "camera_id": camera_id, "timestamp": datetime.utcnow().isoformat(),
                })
                self._alert_cooldowns[key] = now

        for zone_id, count in zone_counts.items():
            zone_threshold = self.overcrowding_threshold // 2
            if count > zone_threshold:
                key = f"overcrowd_{zone_id}"
                if self._is_cooled_down(key, now):
                    anomalies.append({
                        "type": "OVERCROWDING", "severity": "medium",
                        "description": f"Zone {zone_id} overcrowded: {count} people",
                        "track_ids": [], "zone_id": zone_id,
                        "threshold": zone_threshold, "actual_value": count,
                        "camera_id": camera_id, "timestamp": datetime.utcnow().isoformat(),
                    })
                    self._alert_cooldowns[key] = now

        # 3. Speed anomaly
        for track in tracks:
            if track.speed > self.speed_threshold:
                key = f"speed_{track.track_id}"
                if self._is_cooled_down(key, now):
                    anomalies.append({
                        "type": "SPEED_ANOMALY", "severity": "medium",
                        "description": f"Unusual speed for track {track.track_id}: {track.speed:.1f} px/frame",
                        "track_ids": [track.track_id], "zone_id": track.zone_id,
                        "threshold": self.speed_threshold, "actual_value": track.speed,
                        "camera_id": camera_id, "timestamp": datetime.utcnow().isoformat(),
                    })
                    self._alert_cooldowns[key] = now

        # 4. Off-hours
        hour = datetime.now().hour
        if (hour < self.store_open_hour or hour >= self.store_close_hour) and total_active > 0:
            key = "off_hours"
            if self._is_cooled_down(key, now):
                anomalies.append({
                    "type": "OFF_HOURS_ACTIVITY", "severity": "high",
                    "description": f"Activity during off-hours ({hour}:00): {total_active} person(s)",
                    "track_ids": [t.track_id for t in tracks], "zone_id": None,
                    "threshold": 0, "actual_value": total_active,
                    "camera_id": camera_id, "timestamp": datetime.utcnow().isoformat(),
                })
                self._alert_cooldowns[key] = now

        # 5. Zone dwell
        for track in tracks:
            if track.zone_id and track.age_seconds > self.zone_dwell_threshold:
                key = f"dwell_{track.track_id}_{track.zone_id}"
                if self._is_cooled_down(key, now):
                    anomalies.append({
                        "type": "ZONE_DWELL_ALERT", "severity": "low",
                        "description": f"Extended dwell in zone {track.zone_id}: {track.age_seconds:.0f}s",
                        "track_ids": [track.track_id], "zone_id": track.zone_id,
                        "threshold": self.zone_dwell_threshold, "actual_value": track.age_seconds,
                        "camera_id": camera_id, "timestamp": datetime.utcnow().isoformat(),
                    })
                    self._alert_cooldowns[key] = now

        self.anomaly_history.extend(anomalies)
        if len(self.anomaly_history) > 10000:
            self.anomaly_history = self.anomaly_history[-5000:]
        return anomalies

    def _is_cooled_down(self, key, now):
        return (now - self._alert_cooldowns.get(key, 0)) > self._cooldown_period

    def get_recent_anomalies(self, limit=50):
        return self.anomaly_history[-limit:]

    def get_anomaly_counts(self):
        from collections import Counter
        return dict(Counter(a["type"] for a in self.anomaly_history))