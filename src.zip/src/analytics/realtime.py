"""Real-time analytics engine — footfall, zone occupancy, dwell time."""

import time
import structlog
from typing import Dict, List, Optional
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone

logger = structlog.get_logger()


@dataclass
class ZoneMetrics:
    zone_id: str
    current_count: int = 0
    total_entries: int = 0
    total_exits: int = 0
    avg_dwell_time: float = 0.0
    max_dwell_time: float = 0.0
    peak_count: int = 0
    peak_time: Optional[str] = None
    dwell_times: List[float] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "zone_id": self.zone_id, "current_count": self.current_count,
            "total_entries": self.total_entries, "total_exits": self.total_exits,
            "avg_dwell_time": round(self.avg_dwell_time, 2),
            "max_dwell_time": round(self.max_dwell_time, 2),
            "peak_count": self.peak_count, "peak_time": self.peak_time,
        }


class RealtimeAnalytics:
    def __init__(self):
        self.total_footfall = 0
        self.active_count = 0
        self.seen_track_ids = set()
        self.zone_metrics: Dict[str, ZoneMetrics] = {}
        self.track_zones: Dict[int, Optional[str]] = {}
        self.time_series: List[dict] = []
        self._last_bucket_time = time.time()
        self.hourly_footfall: Dict[int, int] = defaultdict(int)

    def update(self, tracks: list, camera_id: str):
        now = time.time()
        self.active_count = len(tracks)

        for track in tracks:
            if track.track_id not in self.seen_track_ids:
                self.seen_track_ids.add(track.track_id)
                self.total_footfall += 1
                self.hourly_footfall[datetime.now().hour] += 1

        zone_counts = defaultdict(int)
        for track in tracks:
            zone_id = track.zone_id
            if zone_id:
                zone_counts[zone_id] += 1
                prev_zone = self.track_zones.get(track.track_id)
                if prev_zone != zone_id:
                    if zone_id not in self.zone_metrics:
                        self.zone_metrics[zone_id] = ZoneMetrics(zone_id=zone_id)
                    self.zone_metrics[zone_id].total_entries += 1
                    if prev_zone and prev_zone in self.zone_metrics:
                        self.zone_metrics[prev_zone].total_exits += 1
                self.track_zones[track.track_id] = zone_id

        for zone_id, count in zone_counts.items():
            if zone_id not in self.zone_metrics:
                self.zone_metrics[zone_id] = ZoneMetrics(zone_id=zone_id)
            zm = self.zone_metrics[zone_id]
            zm.current_count = count
            if count > zm.peak_count:
                zm.peak_count = count
                zm.peak_time = datetime.now(timezone.utc).isoformat()

        for track in tracks:
            if track.zone_id and track.zone_id in self.zone_metrics:
                zm = self.zone_metrics[track.zone_id]
                zm.dwell_times.append(track.age_seconds)
                if len(zm.dwell_times) > 1000:
                    zm.dwell_times = zm.dwell_times[-500:]
                zm.avg_dwell_time = sum(zm.dwell_times) / len(zm.dwell_times)
                zm.max_dwell_time = max(zm.dwell_times)

        if now - self._last_bucket_time >= 60:
            self.time_series.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "active_count": self.active_count,
                "total_footfall": self.total_footfall,
                "zone_counts": dict(zone_counts),
            })
            if len(self.time_series) > 1440:
                self.time_series = self.time_series[-1440:]
            self._last_bucket_time = now

    def get_zone_counts(self) -> Dict[str, int]:
        return {zid: zm.current_count for zid, zm in self.zone_metrics.items()}

    def get_snapshot(self) -> dict:
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "active_count": self.active_count,
            "total_footfall": self.total_footfall,
            "zone_metrics": {zid: zm.to_dict() for zid, zm in self.zone_metrics.items()},
            "avg_dwell_time": 0,
        }

    def get_footfall_timeseries(self) -> List[dict]:
        return self.time_series

    def get_hourly_footfall(self) -> Dict[int, int]:
        return dict(self.hourly_footfall)

    def get_zone_report(self, zone_id: str) -> Optional[dict]:
        zm = self.zone_metrics.get(zone_id)
        return zm.to_dict() if zm else None