"""Analytics module — footfall counting, zone occupancy, heatmaps."""
from .analytics_engine import AnalyticsEngine
__all__ = ["AnalyticsEngine"]