"""Heatmap generator for spatial analytics."""

import cv2
import numpy as np
import base64
import structlog
from typing import Optional

logger = structlog.get_logger()


class HeatmapGenerator:
    def __init__(self, decay_factor=0.995):
        self.width = 0
        self.height = 0
        self.heatmap = None
        self.decay_factor = decay_factor
        self.total_points = 0
        self._initialized = False

    def initialize(self, width, height):
        self.width, self.height = width, height
        self.heatmap = np.zeros((height, width), dtype=np.float32)
        self._initialized = True

    def add_point(self, x, y, weight=1.0):
        if not self._initialized:
            return
        ix, iy = int(x), int(y)
        if 0 <= ix < self.width and 0 <= iy < self.height:
            radius = 25
            y_min, y_max = max(0, iy - radius), min(self.height, iy + radius)
            x_min, x_max = max(0, ix - radius), min(self.width, ix + radius)
            for py in range(y_min, y_max, 2):
                for px in range(x_min, x_max, 2):
                    dist = np.sqrt((px - ix) ** 2 + (py - iy) ** 2)
                    if dist < radius:
                        self.heatmap[py, px] += weight * np.exp(-0.5 * (dist / (radius / 3)) ** 2)
            self.total_points += 1
            if self.total_points % 500 == 0:
                self.heatmap *= self.decay_factor

    def get_heatmap_image(self, colormap=cv2.COLORMAP_JET, alpha=0.6, background=None):
        if not self._initialized:
            return np.zeros((480, 640, 3), dtype=np.uint8)
        normalized = self.heatmap.copy()
        max_val = normalized.max()
        normalized = (normalized / max_val * 255).astype(np.uint8) if max_val > 0 else normalized.astype(np.uint8)
        colored = cv2.applyColorMap(normalized, colormap)
        if background is not None:
            return cv2.addWeighted(background, 1 - alpha, colored, alpha, 0)
        return colored

    def get_heatmap_base64(self):
        img = self.get_heatmap_image()
        _, buffer = cv2.imencode('.png', img)
        return base64.b64encode(buffer).decode('utf-8')

    def get_hotspots(self, top_n=5):
        if not self._initialized:
            return []
        hotspots = []
        hm = self.heatmap.copy()
        for _ in range(top_n):
            max_val = hm.max()
            if max_val <= 0:
                break
            y, x = np.unravel_index(hm.argmax(), hm.shape)
            hotspots.append({"x": int(x), "y": int(y), "intensity": float(max_val)})
            r = 50
            hm[max(0, y-r):min(self.height, y+r), max(0, x-r):min(self.width, x+r)] = 0
        return hotspots

    def reset(self):
        if self._initialized:
            self.heatmap = np.zeros((self.height, self.width), dtype=np.float32)
            self.total_points = 0