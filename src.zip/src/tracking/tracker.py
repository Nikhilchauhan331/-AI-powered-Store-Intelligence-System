"""
DeepSORT-based multi-object tracker.
Wraps deep_sort_realtime and adds per-track state tracking
(dwell time, zone history, velocity).
"""
import time
import numpy as np
from typing import List, Dict, Optional
from dataclasses import dataclass, field
from loguru import logger
import yaml

try:
    from deep_sort_realtime.deepsort_tracker import DeepSort
except ImportError:  # pragma: no cover
    DeepSort = None  # type: ignore[assignment,misc]


@dataclass
class TrackState:
    """Per-track state maintained across frames."""
    track_id: int
    first_seen: float = field(default_factory=time.time)
    last_seen:  float = field(default_factory=time.time)
    positions: List  = field(default_factory=list)   # list of (cx, cy) normalized
    zones_visited: List = field(default_factory=list) # list of zone_id strings
    frame_count: int = 0

    @property
    def dwell_time(self) -> float:
        """Seconds since this track was first seen."""
        return self.last_seen - self.first_seen

    @property
    def velocity(self):
        """Instantaneous velocity from last two positions."""
        if len(self.positions) < 2:
            return 0.0, 0.0
        dx = self.positions[-1][0] - self.positions[-2][0]
        dy = self.positions[-1][1] - self.positions[-2][1]
        return float(dx), float(dy)

    @property
    def speed(self) -> float:
        vx, vy = self.velocity
        return float(np.sqrt(vx ** 2 + vy ** 2))


# Alias used by tests
Track = TrackState


class StoreTracker:
    """
    Wraps DeepSORT and maintains rich per-track state.
    Call update() once per frame with raw YOLO detection dicts.
    """

    def __init__(self, config_path: str = "config/config.yaml"):
        with open(config_path) as f:
            config = yaml.safe_load(f)

        c = config.get("tracking", {})

        if DeepSort is not None:
            self.tracker = DeepSort(
                max_age=c.get("max_age", 30),
                n_init=c.get("min_hits", 3),
                nms_max_overlap=1.0,
                max_cosine_distance=c.get("max_cosine_distance", 0.4),
                nn_budget=c.get("nn_budget", 100),
            )
        else:
            self.tracker = None

        self.track_states: Dict[int, TrackState] = {}
        self.lost_tracks:  Dict[int, TrackState] = {}
        self._grace_period = 5.0
        logger.info(
            f"DeepSORT initialized | max_age={c.get('max_age', 30)} "
            f"min_hits={c.get('min_hits', 3)}"
        )

    def update(self, detections: List[Dict], frame: np.ndarray) -> List[Dict]:
        """
        Update tracker with this frame's raw YOLO detection dicts.

        Args:
            detections: list of {bbox_xyxy: [x1,y1,x2,y2], confidence, class_id}
            frame:      current BGR frame (used for appearance features)

        Returns:
            List of active track dicts with track_id, bbox_norm, center,
            confidence, dwell_time, velocity_x, velocity_y, speed, frame_count
        """
        if self.tracker is None:
            return []

        h, w = frame.shape[:2]

        # Convert to DeepSort format: ([left, top, w, h], conf, cls)
        ds_inputs = []
        for det in detections:
            x1, y1, x2, y2 = det["bbox_xyxy"]
            ds_inputs.append(([x1, y1, x2 - x1, y2 - y1], det["confidence"], det.get("class_id", 0)))

        raw_tracks = self.tracker.update_tracks(ds_inputs, frame=frame)

        active_tracks = []
        now = time.time()

        for track in raw_tracks:
            if not track.is_confirmed():
                continue

            tid  = track.track_id
            ltrb = track.to_ltrb()
            x1, y1, x2, y2 = ltrb

            nx = max(0.0, x1 / w);  ny = max(0.0, y1 / h)
            nw = min(1.0, (x2 - x1) / w); nh = min(1.0, (y2 - y1) / h)
            cx = nx + nw / 2;       cy = ny + nh / 2

            if tid not in self.track_states:
                self.track_states[tid] = TrackState(track_id=tid)
                if tid in self.lost_tracks:
                    self.track_states[tid] = self.lost_tracks.pop(tid)

            state = self.track_states[tid]
            state.last_seen    = now
            state.frame_count += 1
            state.positions.append((cx, cy))
            if len(state.positions) > 60:
                state.positions = state.positions[-60:]

            vx, vy = state.velocity
            active_tracks.append({
                "track_id":    tid,
                "bbox_norm":   (nx, ny, nw, nh),
                "center":      (cx, cy),
                "confidence":  float(track.det_conf or 0.0),
                "dwell_time":  state.dwell_time,
                "velocity_x":  vx,
                "velocity_y":  vy,
                "speed":       state.speed,
                "frame_count": state.frame_count,
            })

        # Move disappeared tracks to lost_tracks
        active_ids = {t["track_id"] for t in active_tracks}
        for tid in list(self.track_states.keys()):
            if tid not in active_ids:
                if now - self.track_states[tid].last_seen > self._grace_period:
                    self.lost_tracks[tid] = self.track_states.pop(tid)

        if len(self.lost_tracks) > 500:
            oldest = min(self.lost_tracks, key=lambda k: self.lost_tracks[k].last_seen)
            del self.lost_tracks[oldest]

        return active_tracks

    def get_track_state(self, track_id: int) -> Optional[TrackState]:
        """Look up state for a track (active or recently lost)."""
        return self.track_states.get(track_id) or self.lost_tracks.get(track_id)

    def update_zone(self, track_id: int, zone_id: str):
        """Record that a track entered a new zone."""
        if track_id in self.track_states:
            state = self.track_states[track_id]
            if not state.zones_visited or state.zones_visited[-1] != zone_id:
                state.zones_visited.append(zone_id)

    def get_all_dwell_times(self) -> Dict[int, float]:
        return {tid: s.dwell_time for tid, s in self.track_states.items()}

    @property
    def active_count(self) -> int:
        return len(self.track_states)


# Aliases for backward compatibility
PersonTracker = StoreTracker
