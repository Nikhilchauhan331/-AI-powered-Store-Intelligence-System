-- ================================================================
-- Store Intelligence System — PostgreSQL Schema
-- ================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── Detections ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS detections (
    id            UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
    timestamp     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    camera_id     VARCHAR(50)  NOT NULL,
    store_id      VARCHAR(50)  NOT NULL,
    track_id      INTEGER      NOT NULL,
    bbox_x        FLOAT        NOT NULL,
    bbox_y        FLOAT        NOT NULL,
    bbox_w        FLOAT        NOT NULL,
    bbox_h        FLOAT        NOT NULL,
    confidence    FLOAT        NOT NULL,
    zone_id       VARCHAR(50),
    frame_number  INTEGER,
    created_at    TIMESTAMPTZ  DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_detections_timestamp  ON detections(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_detections_camera     ON detections(camera_id);
CREATE INDEX IF NOT EXISTS idx_detections_track      ON detections(track_id);
CREATE INDEX IF NOT EXISTS idx_detections_zone       ON detections(zone_id);

-- ── Analytics Snapshots ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS analytics_snapshots (
    id                    UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    timestamp             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    camera_id             VARCHAR(50) NOT NULL,
    store_id              VARCHAR(50) NOT NULL,
    total_count           INTEGER     NOT NULL DEFAULT 0,
    zone_counts           JSONB       DEFAULT '{}',
    avg_dwell_time        FLOAT       DEFAULT 0,
    heatmap_data          JSONB       DEFAULT '{}',
    throughput_per_minute FLOAT       DEFAULT 0,
    created_at            TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_analytics_timestamp  ON analytics_snapshots(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_analytics_camera     ON analytics_snapshots(camera_id);

-- ── Anomalies ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS anomalies (
    id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    timestamp     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    camera_id     VARCHAR(50) NOT NULL,
    store_id      VARCHAR(50) NOT NULL,
    anomaly_type  VARCHAR(50) NOT NULL,
    severity      VARCHAR(20) NOT NULL,
    description   TEXT,
    track_id      INTEGER,
    zone_id       VARCHAR(50),
    metadata      JSONB       DEFAULT '{}',
    resolved      BOOLEAN     DEFAULT FALSE,
    resolved_at   TIMESTAMPTZ,
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_anomalies_timestamp  ON anomalies(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_anomalies_type       ON anomalies(anomaly_type);
CREATE INDEX IF NOT EXISTS idx_anomalies_severity   ON anomalies(severity);
CREATE INDEX IF NOT EXISTS idx_anomalies_resolved   ON anomalies(resolved);

-- ── Track History ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS track_history (
    id                  UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    track_id            INTEGER     NOT NULL,
    camera_id           VARCHAR(50) NOT NULL,
    store_id            VARCHAR(50) NOT NULL,
    first_seen          TIMESTAMPTZ NOT NULL,
    last_seen           TIMESTAMPTZ NOT NULL,
    total_frames        INTEGER     DEFAULT 0,
    zones_visited       JSONB       DEFAULT '[]',
    path_data           JSONB       DEFAULT '[]',
    dwell_time_seconds  FLOAT       DEFAULT 0,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_track_history_track      ON track_history(track_id);
CREATE INDEX IF NOT EXISTS idx_track_history_camera     ON track_history(camera_id);
CREATE INDEX IF NOT EXISTS idx_track_history_first_seen ON track_history(first_seen DESC);