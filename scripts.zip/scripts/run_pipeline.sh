#!/bin/bash
set -euo pipefail

# ================================================================
# Store Intelligence System — Pipeline Launcher
# ================================================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log_info() { echo -e "${GREEN}[INFO]${NC}  $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC}  $1"; }

echo -e "${BLUE}"
echo "  ╔════════════════════════════════════════════╗"
echo "  ║  Store Intelligence System — Starting Up   ║"
echo "  ╚════════════════════════════════════════════╝"
echo -e "${NC}"

# Activate venv
if [ ! -d "venv" ]; then
    echo "Virtual environment not found. Run: bash scripts/setup.sh"
    exit 1
fi
# shellcheck disable=SC1091
source venv/bin/activate
export PYTHONPATH="$(pwd):${PYTHONPATH:-}"

# Load env vars
if [ -f .env ]; then
    set -a; source .env; set +a
fi

# Check video source
VIDEO_SOURCE="${VIDEO_SOURCE:-data/sample.mp4}"
if [ ! -f "$VIDEO_SOURCE" ]; then
    log_warn "Video not found at: $VIDEO_SOURCE"
    log_warn "Using webcam (device 0) as fallback. Set VIDEO_SOURCE=0 in .env for webcam."
fi

# Check Docker services
log_info "Checking Docker services..."
docker compose ps --quiet > /dev/null 2>&1 || {
    log_warn "Docker services not running. Starting..."
    docker compose up -d
    sleep 5
}

mkdir -p logs

# ── Start API Server ──────────────────────────────────────────────
log_info "Starting FastAPI server on port ${API_PORT:-8000}..."
uvicorn src.api.main:app \
    --host "${API_HOST:-0.0.0.0}" \
    --port "${API_PORT:-8000}" \
    --reload \
    --log-level info \
    > logs/api.log 2>&1 &
API_PID=$!
log_info "API server PID: $API_PID"

sleep 2

# Verify API started
if ! kill -0 $API_PID 2>/dev/null; then
    log_warn "API server may have failed. Check logs/api.log"
fi

# ── Start Dashboard ───────────────────────────────────────────────
log_info "Starting Streamlit dashboard on port ${DASHBOARD_PORT:-8501}..."
streamlit run src/dashboard/app.py \
    --server.port "${DASHBOARD_PORT:-8501}" \
    --server.headless true \
    --server.address 0.0.0.0 \
    --browser.gatherUsageStats false \
    > logs/dashboard.log 2>&1 &
DASH_PID=$!
log_info "Dashboard PID: $DASH_PID"

sleep 3

# ── Summary ───────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  All services started!                        ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
echo ""
echo "  → API + Swagger: http://localhost:${API_PORT:-8000}/docs"
echo "  → Dashboard:     http://localhost:${DASHBOARD_PORT:-8501}"
echo "  → Kafka UI:      http://localhost:8080"
echo "  → WebSocket:     ws://localhost:${API_PORT:-8000}/api/v1/ws/events"
echo ""
echo "  Press Ctrl+C to stop all services"
echo ""

# ── Start Main Pipeline ───────────────────────────────────────────
log_info "Starting detection pipeline (VIDEO_SOURCE=${VIDEO_SOURCE})..."
echo ""

# Cleanup handler
cleanup() {
    echo ""
    log_info "Shutting down..."
    kill $API_PID  2>/dev/null || true
    kill $DASH_PID 2>/dev/null || true
    log_info "All services stopped."
    exit 0
}
trap cleanup INT TERM

# Run pipeline (blocking)
python3 -m src.pipeline.pipeline
