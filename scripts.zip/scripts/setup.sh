#!/bin/bash
set -euo pipefail

# ================================================================
# Store Intelligence System — Full Linux Setup Script
# ================================================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log_info()  { echo -e "${GREEN}[INFO]${NC}  $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }
log_step()  { echo -e "\n${BLUE}══> $1${NC}"; }

echo -e "${BLUE}"
echo "  ╔═══════════════════════════════════════════╗"
echo "  ║   Store Intelligence System — Setup        ║"
echo "  ╚═══════════════════════════════════════════╝"
echo -e "${NC}"

# ── Step 1: System checks ─────────────────────────────────────────
log_step "Checking system requirements"

python3 --version > /dev/null 2>&1 || log_error "Python 3 not found. Install: sudo apt install python3 python3-pip python3-venv"
PYTHON_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
log_info "Python $PYTHON_VER found"

docker --version > /dev/null 2>&1 || log_error "Docker not found. Install: https://docs.docker.com/engine/install/"
docker compose version > /dev/null 2>&1 || log_error "Docker Compose v2 not found. Update Docker Desktop or install plugin."
log_info "Docker $(docker --version | awk '{print $3}') found"

# ── Step 2: Install system packages ──────────────────────────────
log_step "Installing system packages"
sudo apt-get update -qq
sudo apt-get install -y -qq \
    libgl1-mesa-glx \
    libglib2.0-0 \
    libsm6 \
    libxext6 \
    libxrender-dev \
    libgomp1 \
    ffmpeg \
    curl \
    wget
log_info "System packages installed"

# ── Step 3: Create project directories ───────────────────────────
log_step "Creating project structure"
mkdir -p data logs models
mkdir -p config scripts
mkdir -p src/{detection,tracking,streaming,analytics,anomaly,pipeline}
mkdir -p src/api/routes
mkdir -p src/{storage,dashboard}
mkdir -p tests

# Create __init__.py files
for dir in src src/detection src/tracking src/streaming \
           src/analytics src/anomaly src/pipeline \
           src/api src/api/routes src/storage src/dashboard tests; do
    touch "$dir/__init__.py"
done
touch data/.gitkeep
log_info "Directory structure created"

# ── Step 4: Python virtual environment ───────────────────────────
log_step "Setting up Python virtual environment"
python3 -m venv venv
# shellcheck disable=SC1091
source venv/bin/activate
pip install --upgrade pip setuptools wheel --quiet
log_info "Virtual environment created at ./venv"

# ── Step 5: Install Python dependencies ──────────────────────────
log_step "Installing Python dependencies (this may take 3-5 minutes)"
pip install -r requirements.txt --quiet
log_info "Python dependencies installed"

# ── Step 6: Environment config ───────────────────────────────────
log_step "Setting up environment configuration"
if [ ! -f .env ]; then
    cp .env.example .env
    log_info "Created .env — edit VIDEO_SOURCE and other settings as needed"
else
    log_warn ".env already exists — skipping copy"
fi

# ── Step 7: Download YOLO model ───────────────────────────────────
log_step "Downloading YOLOv8n model"
python3 -c "
from ultralytics import YOLO
model = YOLO('yolov8n.pt')
print('Model downloaded successfully')
" && log_info "YOLOv8n model ready" || log_warn "YOLO model download failed — will auto-download on first run"

# ── Step 8: Start Docker infrastructure ──────────────────────────
log_step "Starting Docker services (Kafka, PostgreSQL, Redis)"
docker compose up -d

log_info "Waiting for services to be healthy..."
MAX_WAIT=60
WAITED=0
until docker compose exec -T postgres pg_isready -U store_user -d store_intelligence > /dev/null 2>&1; do
    if [ $WAITED -ge $MAX_WAIT ]; then
        log_error "PostgreSQL did not become ready in ${MAX_WAIT}s"
    fi
    echo -n "."
    sleep 2
    WAITED=$((WAITED + 2))
done
echo ""
log_info "PostgreSQL is ready"

# Wait for Kafka
WAITED=0
until docker compose exec -T kafka kafka-broker-api-versions \
    --bootstrap-server localhost:9092 > /dev/null 2>&1; do
    if [ $WAITED -ge $MAX_WAIT ]; then
        log_warn "Kafka not ready yet — topics will be created on first run"
        break
    fi
    echo -n "."
    sleep 2
    WAITED=$((WAITED + 2))
done
echo ""

# ── Step 9: Create Kafka topics ───────────────────────────────────
log_step "Creating Kafka topics"
sleep 3

for topic in store.detections store.analytics store.anomalies store.alerts; do
    docker compose exec -T kafka kafka-topics \
        --create --if-not-exists \
        --bootstrap-server localhost:9092 \
        --topic "$topic" \
        --partitions 3 \
        --replication-factor 1 \
        --config retention.ms=86400000 \
        > /dev/null 2>&1 && log_info "Topic created: $topic" || log_warn "Could not create $topic (will auto-create)"
done

# ── Step 10: Verify database schema ──────────────────────────────
log_step "Verifying database schema"
docker compose exec -T postgres psql -U store_user -d store_intelligence \
    -c "\dt" > /dev/null 2>&1 && log_info "Database schema verified" || \
    log_warn "Could not verify schema — it was applied via init_db.sql on container start"

# ── Done ─────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  ✓  Setup Complete!                           ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
echo ""
echo "  Next steps:"
echo "  1. Add your CCTV video:"
echo "     cp /path/to/your/video.mp4 data/sample.mp4"
echo ""
echo "  2. (Optional) Edit zones in config/config.yaml"
echo "     Adjust polygon coordinates to match your camera layout"
echo ""
echo "  3. Launch the full system:"
echo "     bash scripts/run_pipeline.sh"
echo ""
echo "  Services running:"
echo "    Kafka UI  → http://localhost:8080"
echo ""
